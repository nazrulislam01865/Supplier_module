<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<title>Products &amp; Prices · FlowTrack Supplier Portal</title>
<link rel="stylesheet" href="<?php echo e(asset('assets/supplier.css')); ?>?v=<?php echo e(filemtime(public_path('assets/supplier.css'))); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/supplier-pricing.css')); ?>?v=<?php echo e(filemtime(public_path('assets/supplier-pricing.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/supplier-mobile.css')); ?>?v=<?php echo e(filemtime(public_path('assets/supplier-mobile.css'))); ?>">
</head>
<body>
<section id="portalView" data-catalog-revision="<?php echo e((string) $company->catalog_revision); ?>"
    data-catalog-supplier="<?php echo e((int) $company->flowtrack_supplier_id); ?>"
    data-catalog-key="<?php echo e((string) config('supplier_realtime.key')); ?>"
    data-catalog-host="<?php echo e((string) config('supplier_realtime.host')); ?>"
    data-catalog-port="<?php echo e((int) config('supplier_realtime.port')); ?>"
    data-catalog-scheme="<?php echo e((string) config('supplier_realtime.scheme')); ?>"
    data-catalog-auth="<?php echo e(route('supplier.products.prices.realtime.auth')); ?>"
    data-catalog-revision-url="<?php echo e(route('supplier.products.prices.realtime.revision')); ?>">
    <header class="topbar">
        <div class="topbar-left">
            <button class="btn btn-ghost btn-sm mobile-menu" id="mobileMenuBtn" aria-label="Open menu" type="button"><svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 7h16M4 12h16M4 17h16"/></svg></button>
            <a class="brand" href="<?php echo e(route('supplier.home')); ?>"><?php echo $__env->make('portal.partials.flowtrack-brand', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></a>
        </div>
        <div class="topbar-right">
            <span class="sync-state"><span class="sync-dot"></span>Secure supplier session</span>
            <a class="notification-btn" href="<?php echo e(route('supplier.home')); ?>?view=notifications" aria-label="Notifications"><svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 21h4"/></svg></a>
            <div class="account"><div class="avatar"><?php echo e(strtoupper(mb_substr(request()->user()->name, 0, 1))); ?></div><div class="account-meta"><strong><?php echo e(request()->user()->name); ?></strong><small><?php echo e($company->name); ?></small></div><a class="icon-button" href="<?php echo e(route('supplier.home')); ?>?view=profile" aria-label="Company profile"><svg class="icon-sm" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="m6 9 6 6 6-6"/></svg></a></div>
        </div>
    </header>
    <div class="shell">
        <?php echo $__env->make('portal.partials.sidebar', ['isProductPrices' => true], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <main class="main pricing-main"><div class="content pricing-page">
            <header class="page-header pricing-page-header">
                <div><h1>Products &amp; Prices</h1><p>Products assigned to your company and their approved supplier costs. Customer prices are never shared.</p></div>
                <a class="btn btn-outline-teal pricing-back" href="<?php echo e(route('supplier.home')); ?>"><svg class="icon-sm" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m12 19-7-7 7-7M5 12h15"/></svg>Back to dashboard</a>
            </header>
            <?php if(session('success')): ?><div class="pricing-alert" role="status"><?php echo e(session('success')); ?></div><?php endif; ?>
            <?php if($errors->any()): ?><div class="pricing-alert pricing-alert--error" role="alert"><?php echo e($errors->first()); ?></div><?php endif; ?>
            <div class="pricing-metrics" aria-label="Product pricing overview">
                <div class="pricing-metric"><span class="pricing-metric-icon pricing-metric-icon--products"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m12 2 9 5-9 5-9-5 9-5ZM3 7v10l9 5 9-5V7M12 12v10"/></svg></span><span class="pricing-metric-copy"><span>Total products</span><strong><?php echo e(number_format($totalProducts)); ?></strong></span></div>
                <div class="pricing-metric"><span class="pricing-metric-icon pricing-metric-icon--pending"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M12 6v6l4 2"/></svg></span><span class="pricing-metric-copy"><span>Products with pending requests</span><strong><?php echo e(number_format((int) ($requestCounts?->pending_count ?? 0))); ?></strong></span></div>
                <div class="pricing-metric"><span class="pricing-metric-icon pricing-metric-icon--approved"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.7"><circle cx="12" cy="12" r="9" fill="currentColor" stroke="none"/><path d="m7.5 12 3 3 6-6" stroke="#fff"/></svg></span><span class="pricing-metric-copy"><span>Approved requests</span><strong><?php echo e(number_format((int) ($requestCounts?->approved_count ?? 0))); ?></strong></span></div>
            </div>
            <form class="pricing-filters" method="get" action="<?php echo e(route('supplier.products.prices')); ?>" role="search">
                <div class="pricing-filter pricing-filter--search"><label for="productSearch">Find a product</label><div class="pricing-searchbox"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="10.8" cy="10.8" r="6.5"/><path d="m16 16 5 5"/></svg><input id="productSearch" name="q" value="<?php echo e($search); ?>" maxlength="100" placeholder="Search product name or code" autocomplete="off"></div></div>
                <div class="pricing-filter"><label for="productStatus">Product status</label><select id="productStatus" name="product_status"><option value="">All products</option><option value="active" <?php if($productStatus === 'active'): echo 'selected'; endif; ?>>Active</option><option value="inactive" <?php if($productStatus === 'inactive'): echo 'selected'; endif; ?>>Inactive</option></select></div>
                <div class="pricing-filter"><label for="requestStatus">Request status</label><select id="requestStatus" name="request_status"><option value="">All requests</option><option value="none" <?php if($requestStatus === 'none'): echo 'selected'; endif; ?>>No requests</option><option value="pending" <?php if($requestStatus === 'pending'): echo 'selected'; endif; ?>>Pending approval</option><option value="approved" <?php if($requestStatus === 'approved'): echo 'selected'; endif; ?>>Approved</option><option value="rejected" <?php if($requestStatus === 'rejected'): echo 'selected'; endif; ?>>Changes requested</option><option value="stale" <?php if($requestStatus === 'stale'): echo 'selected'; endif; ?>>Outdated</option></select></div>
                <div class="pricing-filter-actions"><button class="btn btn-primary pricing-search-button" type="submit">Search</button><?php if($search !== '' || $productStatus !== '' || $requestStatus !== ''): ?><a href="<?php echo e(route('supplier.products.prices')); ?>" class="pricing-reset-link">Clear filters</a><?php endif; ?></div>
            </form>
            <div class="pricing-table-card"><div class="pricing-table-scroll"><table class="pricing-list-table">
                <thead><tr><th scope="col">Image</th><th scope="col">Product</th><th scope="col">Current supplier price tiers</th><th scope="col">Latest request</th><th scope="col">Last updated</th><th scope="col">Actions</th></tr></thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php ($payload = $product->payload ?? []); ?>
                    <?php ($tiers = is_array($payload['supplier_prices'] ?? null) ? $payload['supplier_prices'] : []); ?>
                    <?php ($latest = $proposals->get($product->id)); ?>
                    <tr>
                        <td class="pricing-image-cell"><?php echo $__env->make('portal.partials.pricing-product-image', ['payload' => $payload], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></td>
                        <td class="pricing-product-cell"><strong><?php echo e($payload['name'] ?? $product->external_reference); ?></strong><span><?php echo e($payload['code'] ?? $product->external_reference); ?></span><?php if($product->status !== 'active'): ?><small class="pricing-inactive">Inactive product</small><?php endif; ?></td>
                        <td class="pricing-tiers-cell"><?php if(count($tiers)): ?><strong><?php echo e(count($tiers)); ?> <?php echo e(count($tiers) === 1 ? 'tier' : 'tiers'); ?></strong><span>From <?php echo e(number_format((int) ($tiers[0]['quantity'] ?? 0))); ?> units · $<?php echo e(number_format((float) ($tiers[0]['price'] ?? 0), 2)); ?></span><?php else: ?><span>No approved price yet</span><?php endif; ?></td>
                        <td class="pricing-request-cell">
                            <?php if(!$latest): ?><span class="pricing-pill pricing-pill--none">No requests</span><small>—</small>
                            <?php else: ?>
                                <span class="pricing-pill pricing-pill--<?php echo e($latest->status); ?>"><?php if($latest->status === 'pending'): ?><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><circle cx="12" cy="12" r="9"/><path d="M12 6v6l4 2"/></svg>Pending approval <?php elseif($latest->status === 'approved'): ?><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6"><path d="m4 12 5 5L20 6"/></svg>Approved <?php elseif($latest->status === 'rejected'): ?><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6"><circle cx="12" cy="12" r="9"/><path d="M12 7v6m0 4h.01"/></svg>Changes requested <?php else: ?><?php echo e(ucfirst($latest->status)); ?><?php endif; ?></span>
                                <small><?php echo e($latest->status === 'approved' ? 'Approved' : 'Requested'); ?> <?php echo e(($latest->status === 'approved' ? $latest->updated_at : $latest->created_at)?->format('M j, Y')); ?></small>
                            <?php endif; ?>
                        </td>
                        <td class="pricing-updated"><?php echo e($product->updated_at?->format('M j, Y') ?? '—'); ?></td>
                        <td class="pricing-list-actions"><a class="btn btn-outline-teal pricing-action" href="<?php echo e(route('supplier.products.prices.show', $product->id)); ?>">View</a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="6" class="pricing-empty"><?php echo e(($search !== '' || $productStatus !== '' || $requestStatus !== '') ? 'No assigned products match your filters.' : 'No products are currently assigned to your company.'); ?></td></tr><?php endif; ?>
                </tbody>
            </table></div>
            <div class="pricing-table-footer"><span>Showing <?php echo e($products->firstItem() ?? 0); ?> to <?php echo e($products->lastItem() ?? 0); ?> of <?php echo e(number_format($products->total())); ?> products</span><div class="pricing-pagination"><?php echo e($products->withQueryString()->onEachSide(2)->links('portal.partials.pricing-pagination')); ?></div></div>
            </div>
        </div></main>
    </div>
</section>
<script src="<?php echo e(asset('assets/supplier-pricing.js')); ?>?v=<?php echo e(filemtime(public_path('assets/supplier-pricing.js'))); ?>" defer nonce="<?php echo e(request()->attributes->get('csp_nonce')); ?>"></script>
<script src="<?php echo e(asset('assets/supplier-catalog-realtime.js')); ?>?v=<?php echo e(filemtime(public_path('assets/supplier-catalog-realtime.js'))); ?>" defer nonce="<?php echo e(request()->attributes->get('csp_nonce')); ?>"></script>
<script src="<?php echo e(asset('assets/supplier-mobile.js')); ?>?v=<?php echo e(filemtime(public_path('assets/supplier-mobile.js'))); ?>" defer nonce="<?php echo e(request()->attributes->get('csp_nonce')); ?>"></script>
</body></html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/flowtrack/supplier-portal/resources/views/portal/product-prices.blade.php ENDPATH**/ ?>