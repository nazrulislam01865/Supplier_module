<?php
    $summaryClass = 'is-'.$stage['status'];
?>
<div class="supplier-prototype-stage-summary <?php echo e($summaryClass); ?>">
    <div class="supplier-prototype-stage-summary-icon">
        <?php if($stage['status'] === 'completed'): ?>
            <?php echo $__env->make('portal.order.partials.svg.check', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php else: ?>
            <span class="supplier-prototype-stage-summary-ring"></span>
        <?php endif; ?>
    </div>
    <div class="supplier-prototype-stage-summary-copy">
        <div class="supplier-prototype-stage-summary-top">
            <strong><?php echo e($stage['name']); ?></strong>
            <span class="supplier-prototype-status-pill is-<?php echo e($stage['status']); ?>"><?php echo e($stage['status_label']); ?></span>
        </div>
        <span><?php echo e($stage['helper']); ?></span>
    </div>
</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/flowtrack/supplier-portal/resources/views/portal/order/partials/stage-summary-card.blade.php ENDPATH**/ ?>