<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e($summary['title']); ?> · FlowTrack Supplier Portal</title>
    <link rel="stylesheet" href="<?php echo e(asset('assets/supplier.css')); ?>?v=<?php echo e(filemtime(public_path('assets/supplier.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/supplier-workflow.css')); ?>?v=<?php echo e(filemtime(public_path('assets/supplier-workflow.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/supplier-mobile.css')); ?>?v=<?php echo e(filemtime(public_path('assets/supplier-mobile.css'))); ?>">
</head>
<body id="supplierOrderView" class="supplier-prototype-body"
    data-order-realtime-id="<?php echo e($order->id); ?>"
    data-order-realtime-revision="<?php echo e((string) ($order->payload['revision'] ?? '0')); ?>"
    data-order-realtime-supplier="<?php echo e((int) $company->flowtrack_supplier_id); ?>"
    data-order-realtime-source="<?php echo e((int) ($order->payload['source_id'] ?? 0)); ?>"
    data-order-realtime-key="<?php echo e((string) config('supplier_realtime.key')); ?>"
    data-order-realtime-host="<?php echo e((string) config('supplier_realtime.host')); ?>"
    data-order-realtime-port="<?php echo e((int) config('supplier_realtime.port')); ?>"
    data-order-realtime-scheme="<?php echo e((string) config('supplier_realtime.scheme')); ?>"
    data-order-realtime-auth="<?php echo e(route('supplier.orders.realtime.auth', $order->id)); ?>"
    data-order-realtime-revision-url="<?php echo e(route('supplier.orders.realtime.revision', $order->id)); ?>">
<section id="portalView">
    <header class="topbar">
        <div class="topbar-left">
            <button class="btn btn-ghost btn-sm mobile-menu" id="mobileMenuBtn" aria-label="Open menu" type="button">
                <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 7h16M4 12h16M4 17h16"/></svg>
            </button>
            <a class="brand" href="<?php echo e(route('supplier.home')); ?>"><?php echo $__env->make('portal.partials.flowtrack-brand', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></a>
        </div>
        <div class="topbar-right">
            <span class="sync-state"><span class="sync-dot"></span>Secure supplier session</span>
            <a class="notification-btn" href="<?php echo e(route('supplier.home')); ?>?view=notifications" aria-label="Notifications">
                <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 21h4"/></svg>
                <span class="notification-dot"></span>
            </a>
            <div class="account">
                <div class="avatar"><?php echo e(strtoupper(substr($user->name, 0, 1))); ?></div>
                <div class="account-meta"><strong><?php echo e($user->name); ?></strong><small><?php echo e($company->name); ?></small></div>
                <a class="icon-button" href="<?php echo e(route('supplier.home')); ?>?view=profile" aria-label="Company profile">
                    <svg class="icon-sm" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="m6 9 6 6 6-6"/></svg>
                </a>
            </div>
        </div>
    </header>
    <div class="shell">
        <?php echo $__env->make('portal.partials.sidebar', ['isOrderDetail' => true], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <main class="main supplier-prototype-main">
        <div class="supplier-prototype-content">
            <div class="supplier-prototype-breadcrumb-row">
                <div class="supplier-prototype-breadcrumbs">
                    <a href="<?php echo e(route('supplier.home')); ?>?view=orders">Orders</a>
                    <span>/</span>
                    <strong><?php echo e($summary['breadcrumb_reference']); ?></strong>
                    <button type="button" class="supplier-prototype-copy-btn" aria-label="Copy order reference" data-copy-reference="<?php echo e($summary['breadcrumb_reference']); ?>">
                        <?php echo $__env->make('portal.order.partials.svg.copy', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </button>
                </div>
                <a href="<?php echo e(route('supplier.home')); ?>?view=orders" class="supplier-prototype-back-btn">
                    <?php echo $__env->make('portal.order.partials.svg.arrow-left', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <span>Back to orders</span>
                </a>
            </div>

            <header class="supplier-prototype-header">
                <h1><?php echo e($summary['title']); ?></h1>
            </header>

            <div class="supplier-prototype-grid">
                <div class="supplier-prototype-primary-column">
                    <section class="supplier-prototype-card supplier-prototype-card--table">
                        <header class="supplier-prototype-card-head"><h2>Products (Your supply)</h2></header>
                        <div class="supplier-prototype-table-wrap">
                            <table class="supplier-prototype-table">
                                <thead>
                                    <tr>
                                        <th>Product</th>
                                        <th>Quantity</th>
                                        <th>Unit Price</th>
                                        <th>Total Price</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td>
                                            <div class="supplier-prototype-product-cell">
                                                <div class="supplier-prototype-product-thumb supplier-prototype-file-placeholder" aria-hidden="true"><?php echo $__env->make('portal.order.partials.svg.box', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div>
                                                <div>
                                                    <strong><?php echo e($item['product_name']); ?></strong>
                                                    <?php if(filled($item['notes'])): ?><small class="supplier-order-product-notes"><?php echo e($item['notes']); ?></small><?php endif; ?>
                                                </div>
                                            </div>
                                        </td>
                                        <td><strong class="supplier-prototype-table-strong"><?php echo e($item['quantity_label']); ?></strong></td>
                                        <td><strong class="supplier-prototype-table-strong"><?php echo e($item['unit_price_label']); ?></strong></td>
                                        <td><strong class="supplier-prototype-table-strong"><?php echo e($item['total_price_label']); ?></strong></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="4" class="supplier-prototype-empty-row">No product lines available.</td>
                                    </tr>
                                <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </section>
                    <?php echo $__env->make('portal.order.partials.workflow', ['workflow' => $workflow, 'order' => $order], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>

                <aside class="supplier-prototype-side-column">
                    <section class="supplier-prototype-card">
                        <header class="supplier-prototype-card-head supplier-prototype-card-head--icon">
                            <div class="supplier-prototype-side-title">
                                <span class="supplier-prototype-side-icon"><?php echo $__env->make('portal.order.partials.svg.calendar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></span>
                                <h2>Recent updates</h2>
                            </div>
                        </header>
                        <div class="supplier-prototype-card-body supplier-prototype-recent-list">
                            <?php $__empty_1 = true; $__currentLoopData = $recentUpdates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $update): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php echo $__env->make('portal.order.partials.recent-update', ['update' => $update], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="supplier-prototype-empty-state">No workflow updates have been received yet.</div>
                            <?php endif; ?>
                        </div>
                    </section>

                    <section class="supplier-prototype-card">
                        <header class="supplier-prototype-card-head supplier-prototype-card-head--icon">
                            <div class="supplier-prototype-side-title">
                                <span class="supplier-prototype-side-icon"><?php echo $__env->make('portal.order.partials.svg.file', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></span>
                                <h2>Approved artwork</h2>
                            </div>
                        </header>
                        <div class="supplier-prototype-card-body">
                            <?php if(count($approvedArtworks)): ?>
                                <?php $__currentLoopData = $approvedArtworks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $approvedArtwork): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="supplier-prototype-side-artwork-file">
                                    <div class="supplier-prototype-artwork-media">
                                        <div class="supplier-prototype-artwork-thumb supplier-prototype-file-placeholder" aria-hidden="true"><?php echo $__env->make('portal.order.partials.svg.file-doc', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div>
                                        <div class="supplier-prototype-artwork-copy">
                                            <strong><?php echo e($approvedArtwork['name']); ?></strong>
                                            <span><?php echo e(number_format(($approvedArtwork['size'] ?? 0) / 1048576, 1)); ?> MB &nbsp; • &nbsp; <?php echo e(strtoupper(pathinfo($approvedArtwork['name'], PATHINFO_EXTENSION) ?: 'FILE')); ?></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="supplier-prototype-key-value-list">
                                    <?php if(filled($approvedArtwork['uploaded_at'] ?? null)): ?>
                                        <div><span>Uploaded on</span><strong><?php echo e(\Illuminate\Support\Carbon::parse($approvedArtwork['uploaded_at'])->format('M j, Y')); ?></strong></div>
                                    <?php endif; ?>
                                    <?php if(!empty($approvedArtwork['version'])): ?>
                                        <div><span>Version</span><strong>V<?php echo e($approvedArtwork['version']); ?></strong></div>
                                    <?php endif; ?>
                                </div>
                                <a class="supplier-prototype-view-btn" style="display:inline-flex;margin:9px 0 16px" href="<?php echo e(route('supplier.orders.artwork', [$order->id, $approvedArtwork['id']])); ?>">Download artwork</a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <div class="supplier-prototype-empty-state">No approved artwork file available. It will appear after confirmation and synchronization.</div>
                            <?php endif; ?>
                        </div>
                    </section>
                </aside>
            </div>
        </div>
        </main>
    </div>
</section>
<script nonce="<?php echo e(request()->attributes->get('csp_nonce')); ?>">
(function () {
    var menu = document.getElementById('mobileMenuBtn');
    var sidebar = document.getElementById('sidebar');
    if (menu && sidebar) {
        menu.addEventListener('click', function () { sidebar.classList.toggle('open'); });
    }
    document.querySelectorAll('[data-stage-toggle]').forEach(function (button) {
        var panel = document.getElementById(button.getAttribute('aria-controls'));
        if (!panel) return;
        button.addEventListener('click', function () {
            panel.hidden = !panel.hidden;
            button.setAttribute('aria-expanded', String(!panel.hidden));
            button.classList.toggle('is-collapsed', panel.hidden);
        });
    });
    var workflow = document.querySelector('[data-supplier-workflow]');
    if (workflow) {
        workflow.querySelectorAll('[data-flow-stage]').forEach(function (button) {
            button.addEventListener('click', function () {
                if (button.getAttribute('aria-disabled') === 'true') return;
                workflow.querySelectorAll('[data-flow-stage]').forEach(function (card) {
                    var selected = card === button;
                    card.classList.toggle('viewing', selected);
                    card.setAttribute('aria-selected', String(selected));
                });
                workflow.querySelectorAll('[data-flow-panel]').forEach(function (panel) {
                    panel.hidden = panel.dataset.flowPanel !== button.dataset.flowStage;
                });
            });
        });
    }
    // Keep every action dialog outside the task table's grid and overflow container.
    // The native modal stays in the browser top layer, independent of task-row height.
    var actionDialogs = Array.prototype.slice.call(document.querySelectorAll('[data-supplier-action-dialog]'));
    actionDialogs.forEach(function (dialog) {
        document.body.appendChild(dialog);
        var opener = document.querySelector('[data-supplier-modal-open="' + dialog.id + '"]');
        var form = dialog.querySelector('[data-supplier-action-form]');
        if (!form) return;
        function closeDialog() {
            if (dialog.open) dialog.close();
        }
        if (opener) opener.addEventListener('click', function () {
            if (typeof dialog.showModal === 'function' && !dialog.open) dialog.showModal();
        });
        dialog.querySelectorAll('[data-supplier-modal-close]').forEach(function (button) {
            button.addEventListener('click', closeDialog);
        });
        dialog.addEventListener('close', function () {
            if (opener) opener.focus({ preventScroll: true });
        });
        var choice = form.querySelector('[data-supplier-client-choice]');
        var submit = form.querySelector('[data-supplier-action-submit]');
        var stage = function (name) {
            form.querySelectorAll('[data-client-decision-stage]').forEach(function (panel) {
                panel.hidden = panel.dataset.clientDecisionStage !== name;
            });
        };
        if (choice) {
            submit.disabled = !choice.value;
            if (choice.value === 'revise') stage('revision');
            else if (choice.value === 'sample' || choice.value === 'confirm') stage('sample');
            form.querySelectorAll('[data-client-action]').forEach(function (button) {
                button.addEventListener('click', function () {
                    var decision = button.dataset.clientAction;
                    if (decision === 'approved') {
                        choice.value = '';
                        submit.disabled = true;
                        stage('sample');
                    } else if (decision === 'revise') {
                        choice.value = 'revise';
                        submit.disabled = false;
                        stage('revision');
                    } else {
                        choice.value = decision;
                        submit.disabled = false;
                        form.querySelectorAll('[data-client-action]').forEach(function (other) {
                            other.classList.toggle('selected', other === button);
                        });
                    }
                });
            });
            form.querySelectorAll('[data-client-back]').forEach(function (button) {
                button.addEventListener('click', function () {
                    choice.value = '';
                    submit.disabled = true;
                    stage('choice');
                });
            });
        }
        form.addEventListener('submit', function (event) {
            if (choice && !choice.value) {
                event.preventDefault();
                return;
            }
            if (form.dataset.submitting === 'true') { event.preventDefault(); return; }
            if (form.checkValidity()) {
                form.dataset.submitting = 'true';
                submit.disabled = true;
                submit.textContent = 'Saving in FlowTracker…';
            }
        });
    });
    // Reopen the original modal after server-side validation and preserve form fields.
    var invalidTask = <?php echo json_encode(old('_supplier_workflow_task'), 15, 512) ?>;
    if (invalidTask) {
        var invalidDialog = document.getElementById('supplier-flow-dialog-' + invalidTask);
        if (invalidDialog && typeof invalidDialog.showModal === 'function' && !invalidDialog.open) invalidDialog.showModal();
    }
    var copy = document.querySelector('[data-copy-reference]');
    if (copy && navigator.clipboard && navigator.clipboard.writeText) {
        copy.addEventListener('click', function () {
            navigator.clipboard.writeText(copy.getAttribute('data-copy-reference')).then(function () {
                copy.setAttribute('aria-label', 'Order reference copied');
            }).catch(function () {});
        });
    }
})();
</script>
<script src="<?php echo e(asset('assets/supplier-order-realtime.js')); ?>?v=<?php echo e(filemtime(public_path('assets/supplier-order-realtime.js'))); ?>" defer nonce="<?php echo e(request()->attributes->get('csp_nonce')); ?>"></script>
<script src="<?php echo e(asset('assets/supplier-mobile.js')); ?>?v=<?php echo e(filemtime(public_path('assets/supplier-mobile.js'))); ?>" defer nonce="<?php echo e(request()->attributes->get('csp_nonce')); ?>"></script>
</body>
</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/flowtrack/supplier-portal/resources/views/portal/order/show.blade.php ENDPATH**/ ?>