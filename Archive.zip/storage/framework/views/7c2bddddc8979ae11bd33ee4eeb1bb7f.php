<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<title>Product Details · FlowTrack Supplier Portal</title>
<link rel="stylesheet" href="<?php echo e(asset('assets/supplier.css')); ?>?v=<?php echo e(filemtime(public_path('assets/supplier.css'))); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/supplier-pricing.css')); ?>?v=<?php echo e(filemtime(public_path('assets/supplier-pricing.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/supplier-mobile.css')); ?>?v=<?php echo e(filemtime(public_path('assets/supplier-mobile.css'))); ?>">
</head>
<body>
<section id="portalView" data-catalog-revision="<?php echo e((string) $company->catalog_revision); ?>"
    data-catalog-supplier="<?php echo e((int) $company->flowtrack_supplier_id); ?>"
    data-catalog-key="<?php echo e((string) config('supplier_realtime.key')); ?>"
    data-catalog-host="<?php echo e((string) config('supplier_realtime.host')); ?>"
    data-catalog-port="<?php echo e((int) config('supplier_realtime.port')); ?>"
    data-catalog-scheme="<?php echo e((string) config('supplier_realtime.scheme')); ?>"
    data-catalog-auth="<?php echo e(route('supplier.products.prices.realtime.auth')); ?>"
    data-catalog-revision-url="<?php echo e(route('supplier.products.prices.realtime.revision')); ?>">
    <header class="topbar">
        <div class="topbar-left">
            <button class="btn btn-ghost btn-sm mobile-menu" id="mobileMenuBtn" aria-label="Open menu" type="button"><svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 7h16M4 12h16M4 17h16"/></svg></button>
            <a class="brand" href="<?php echo e(route('supplier.home')); ?>"><?php echo $__env->make('portal.partials.flowtrack-brand', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></a>
        </div>
        <div class="topbar-right">
            <span class="sync-state"><span class="sync-dot"></span>Secure supplier session</span>
            <a class="notification-btn" href="<?php echo e(route('supplier.home')); ?>?view=notifications" aria-label="Notifications"><svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 21h4"/></svg></a>
            <div class="account"><div class="avatar"><?php echo e(strtoupper(mb_substr(request()->user()->name, 0, 1))); ?></div><div class="account-meta"><strong><?php echo e(request()->user()->name); ?></strong><small><?php echo e($company->name); ?></small></div><a class="icon-button" href="<?php echo e(route('supplier.home')); ?>?view=profile" aria-label="Company profile"><svg class="icon-sm" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="m6 9 6 6 6-6"/></svg></a></div>
        </div>
    </header>
    <div class="shell">
        <?php echo $__env->make('portal.partials.sidebar', ['isProductPrices' => true], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <main class="main pricing-main"><div class="content pricing-page pricing-editor-page">
            <header class="page-header pricing-page-header">
                <div><h1>Product Details</h1><p>View your assigned product and its approved supplier prices.</p></div>
                <a class="btn btn-outline-teal pricing-back" href="<?php echo e(route('supplier.products.prices')); ?>"><svg class="icon-sm" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m12 19-7-7 7-7M5 12h15"/></svg>Back to products</a>
            </header>
            <?php if(session('success')): ?><div class="pricing-alert" role="status"><?php echo e(session('success')); ?></div><?php endif; ?>
            <?php if($errors->any()): ?><div class="pricing-alert pricing-alert--error" role="alert"><?php echo e($errors->first()); ?></div><?php endif; ?>
            <?php ($payload = $product->payload ?? []); ?>
            <?php ($tiers = is_array($payload['supplier_prices'] ?? null) ? $payload['supplier_prices'] : []); ?>
            <section class="pricing-product-summary pricing-product-detail-summary">
                <?php echo $__env->make('portal.partials.pricing-product-image', ['payload' => $payload, 'large' => true], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <div class="pricing-product-summary-text">
                    <div class="pricing-product-heading"><h2><?php echo e($payload['name'] ?? $product->external_reference); ?></h2><span class="pricing-active-badge <?php echo e($product->status !== 'active' ? 'pricing-active-badge--inactive' : ''); ?>"><span></span><?php echo e($product->status === 'active' ? 'Active product' : 'Inactive product'); ?></span></div>
                    <div class="pricing-product-sku"><?php echo e($payload['code'] ?? $product->external_reference); ?></div>
                    <div class="pricing-product-timestamp">Last updated <?php echo e($product->updated_at?->format('M j, Y') ?? '—'); ?></div>
                </div>
                <?php if($product->status === 'active' && $latest?->status !== 'pending'): ?>
                    <a class="btn btn-primary pricing-detail-edit" href="<?php echo e(route('supplier.products.prices.edit', $product->id)); ?>">Edit Prices</a>
                <?php endif; ?>
            </section>
            <?php if($latest?->status === 'pending'): ?>
                <div class="pricing-pending-note" role="status">A price request is pending approval. Current approved prices remain unchanged, and editing is unavailable until it is reviewed.</div>
            <?php elseif($latest && $latest->review_note): ?>
                <div class="pricing-review-note" role="status">Latest request: <?php echo e(ucfirst($latest->status)); ?> — <?php echo e($latest->review_note); ?></div>
            <?php endif; ?>
            <div class="pricing-detail-grid">
                <section class="pricing-editor-card pricing-detail-prices">
                    <header class="pricing-editor-card-header"><h2>Current Supplier Price Tiers</h2><p>Approved supplier unit prices for this product (USD).</p></header>
                    <div class="pricing-tier-scroll"><table class="pricing-details-table">
                        <thead><tr><th scope="col">Quantity</th><th scope="col">Approved Unit Price (USD)</th></tr></thead>
                        <tbody><?php $__empty_1 = true; $__currentLoopData = $tiers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr><td><?php echo e(number_format((int) ($tier['quantity'] ?? 0))); ?></td><td>$<?php echo e(number_format((float) ($tier['price'] ?? 0), 2)); ?></td></tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="2" class="pricing-tier-empty">No approved supplier prices available.</td></tr><?php endif; ?></tbody>
                    </table></div>
                </section>
                <section class="pricing-editor-card pricing-detail-request">
                    <header class="pricing-editor-card-header"><h2>Latest Price Request</h2></header>
                    <?php if($latest): ?>
                        <div class="pricing-detail-meta"><span>Request status</span><span class="pricing-pill pricing-pill--<?php echo e($latest->status); ?>"><?php echo e(match ($latest->status) { 'pending' => 'Pending approval', 'approved' => 'Approved', 'rejected' => 'Changes requested', 'stale' => 'Outdated', default => ucfirst($latest->status) }); ?></span></div>
                        <div class="pricing-detail-meta"><span>Submitted</span><span><?php echo e($latest->created_at?->format('M j, Y') ?? '—'); ?></span></div>
                        <?php if($latest->status === 'approved'): ?><div class="pricing-detail-meta"><span>Approved</span><span><?php echo e($latest->updated_at?->format('M j, Y') ?? '—'); ?></span></div><?php endif; ?>
                    <?php else: ?>
                        <p class="pricing-detail-no-requests">No price change requests for this product.</p>
                    <?php endif; ?>
                </section>
            </div>
        </div></main>
    </div>
</section>
<script src="<?php echo e(asset('assets/supplier-pricing.js')); ?>?v=<?php echo e(filemtime(public_path('assets/supplier-pricing.js'))); ?>" defer nonce="<?php echo e(request()->attributes->get('csp_nonce')); ?>"></script>
<script src="<?php echo e(asset('assets/supplier-catalog-realtime.js')); ?>?v=<?php echo e(filemtime(public_path('assets/supplier-catalog-realtime.js'))); ?>" defer nonce="<?php echo e(request()->attributes->get('csp_nonce')); ?>"></script>
<script src="<?php echo e(asset('assets/supplier-mobile.js')); ?>?v=<?php echo e(filemtime(public_path('assets/supplier-mobile.js'))); ?>" defer nonce="<?php echo e(request()->attributes->get('csp_nonce')); ?>"></script>
</body></html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/flowtrack/supplier-portal/resources/views/portal/product-price-show.blade.php ENDPATH**/ ?>