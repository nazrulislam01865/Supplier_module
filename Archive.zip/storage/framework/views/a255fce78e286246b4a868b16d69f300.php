<div class="supplier-prototype-meta-item">
    <div class="supplier-prototype-meta-icon"><?php echo $__env->make($icon, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div>
    <div>
        <span><?php echo e($label); ?></span>
        <strong><?php echo e($value); ?></strong>
    </div>
</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/flowtrack/supplier-portal/resources/views/portal/order/partials/meta-item.blade.php ENDPATH**/ ?>