<?php
    $panelClass = 'is-'.$stage['status'];
?>
<section class="supplier-prototype-stage-panel <?php echo e($panelClass); ?>">
    <div class="supplier-prototype-stage-rail">
        <div class="supplier-prototype-stage-rail-dot is-<?php echo e($stage['status']); ?>">
            <?php if($stage['status'] === 'completed'): ?>
                <?php echo $__env->make('portal.order.partials.svg.check', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endif; ?>
        </div>
    </div>
    <div class="supplier-prototype-stage-panel-card">
        <header class="supplier-prototype-stage-panel-head">
            <div class="supplier-prototype-stage-panel-title-wrap">
                <div class="supplier-prototype-stage-panel-icon is-<?php echo e($stage['status']); ?>"><?php echo $__env->make('portal.order.partials.svg.folder', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div>
                <div class="supplier-prototype-stage-panel-title">
                    <strong><?php echo e($stage['name']); ?></strong>
                    <span class="supplier-prototype-status-pill is-<?php echo e($stage['status']); ?>"><?php echo e($stage['status_label']); ?></span>
                </div>
            </div>
            <div class="supplier-prototype-stage-panel-meta">
                <?php if($stage['headline_date'] !== '—'): ?>
                    <span><?php echo e($stage['headline_date']); ?></span>
                <?php endif; ?>
                <button type="button" class="supplier-prototype-collapse-indicator <?php echo e($stage['status'] === 'upcoming' ? 'is-collapsed' : ''); ?>" aria-label="Toggle <?php echo e($stage['name']); ?> tasks" aria-controls="supplier-stage-<?php echo e($stage['key']); ?>" aria-expanded="<?php echo e($stage['status'] === 'upcoming' ? 'false' : 'true'); ?>" data-stage-toggle>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="m6 14 6-6 6 6"/></svg>
                </button>
            </div>
        </header>

        <div class="supplier-prototype-stage-details" id="supplier-stage-<?php echo e($stage['key']); ?>" <?php if($stage['status'] === 'upcoming'): ?> hidden <?php endif; ?>>
        <?php if(!empty($stage['tasks'])): ?>
            <div class="supplier-prototype-stage-task-list">
                <?php $__currentLoopData = $stage['tasks']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="supplier-prototype-stage-task-row">
                        <div class="supplier-prototype-stage-task-name">
                            <?php echo $__env->make('portal.order.partials.svg.file-doc', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            <span><?php echo e($task['index']); ?>. <?php echo e($task['name']); ?></span>
                        </div>
                        <div class="supplier-prototype-stage-task-status is-<?php echo e($task['status']); ?>">
                            <span class="supplier-prototype-stage-task-status-icon"></span>
                            <strong><?php echo e($task['status_label']); ?></strong>
                        </div>
                        <div class="supplier-prototype-stage-task-date"><?php echo e($task['date_label']); ?></div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

        <?php if($stage['key'] === 'artwork' && $stage['document']): ?>
            <div class="supplier-prototype-stage-artwork-box">
                <div class="supplier-prototype-stage-artwork-head">Approved artwork</div>
                <div class="supplier-prototype-stage-artwork-row">
                    <div class="supplier-prototype-artwork-media">
                        <div class="supplier-prototype-artwork-thumb supplier-prototype-artwork-thumb--large supplier-prototype-file-placeholder" aria-hidden="true">
                            <?php echo $__env->make('portal.order.partials.svg.file-doc', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        </div>
                        <div class="supplier-prototype-artwork-copy">
                            <strong><?php echo e($stage['document']['name']); ?></strong>
                            <span><?php echo e(number_format(($stage['document']['size'] ?? 0) / 1048576, 1)); ?> MB &nbsp; • &nbsp; <?php echo e(strtoupper(pathinfo($stage['document']['name'], PATHINFO_EXTENSION) ?: 'FILE')); ?></span>
                        </div>
                    </div>
                    <a class="supplier-prototype-view-btn" href="<?php echo e(route('supplier.orders.artwork', [$order->id, $stage['document']['id']])); ?>">Download</a>
                </div>
            </div>
        <?php endif; ?>
        </div>
    </div>
</section>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/flowtrack/supplier-portal/resources/views/portal/order/partials/stage-panel.blade.php ENDPATH**/ ?>