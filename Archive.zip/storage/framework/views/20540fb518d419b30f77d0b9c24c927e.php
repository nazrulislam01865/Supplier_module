<?php ($product = \App\Services\SupplierDashboardData::class); ?>
<?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <?php ($new = ! $user->notifications_read_at || $notice->updated_at->gt($user->notifications_read_at)); ?>
    <?php if($notice->type === 'rfq'): ?>
        <button type="button" class="notice supplier-notice-link <?php echo e($new ? 'supplier-notice-new' : ''); ?>" data-open-rfq="<?php echo e($notice->id); ?>">
            <span class="notice-icon">RFQ</span><span><strong><?php echo e($notice->external_reference); ?> · <?php echo e(ucfirst($notice->status)); ?></strong><span><?php echo e($product::product($notice)); ?></span><time><?php echo e($notice->updated_at->diffForHumans()); ?></time></span>
        </button>
    <?php else: ?>
        <a class="notice supplier-notice-link <?php echo e($new ? 'supplier-notice-new' : ''); ?>" href="<?php echo e($product::link($notice)); ?>">
            <span class="notice-icon">ORD</span><span><strong><?php echo e($notice->external_reference); ?> · <?php echo e(data_get($notice->payload, 'order_status', 'Order updated')); ?></strong><span><?php echo e($product::product($notice)); ?></span><time><?php echo e($notice->updated_at->diffForHumans()); ?></time></span>
        </a>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="empty-state"><h3>No notifications</h3><p>Assigned RFQ and order updates will appear here.</p></div>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/flowtrack/supplier-portal/resources/views/portal/partials/notifications.blade.php ENDPATH**/ ?>