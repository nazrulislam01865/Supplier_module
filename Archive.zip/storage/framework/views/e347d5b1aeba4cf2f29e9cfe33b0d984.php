<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<title>Edit Supplier Prices · FlowTrack Supplier Portal</title>
<link rel="stylesheet" href="<?php echo e(asset('assets/supplier.css')); ?>?v=<?php echo e(filemtime(public_path('assets/supplier.css'))); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/supplier-pricing.css')); ?>?v=<?php echo e(filemtime(public_path('assets/supplier-pricing.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/supplier-mobile.css')); ?>?v=<?php echo e(filemtime(public_path('assets/supplier-mobile.css'))); ?>">
</head>
<body>
<section id="portalView" data-catalog-revision="<?php echo e((string) $company->catalog_revision); ?>"
    data-catalog-supplier="<?php echo e((int) $company->flowtrack_supplier_id); ?>"
    data-catalog-key="<?php echo e((string) config('supplier_realtime.key')); ?>"
    data-catalog-host="<?php echo e((string) config('supplier_realtime.host')); ?>"
    data-catalog-port="<?php echo e((int) config('supplier_realtime.port')); ?>"
    data-catalog-scheme="<?php echo e((string) config('supplier_realtime.scheme')); ?>"
    data-catalog-auth="<?php echo e(route('supplier.products.prices.realtime.auth')); ?>"
    data-catalog-revision-url="<?php echo e(route('supplier.products.prices.realtime.revision')); ?>">
    <header class="topbar">
        <div class="topbar-left">
            <button class="btn btn-ghost btn-sm mobile-menu" id="mobileMenuBtn" aria-label="Open menu" type="button"><svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 7h16M4 12h16M4 17h16"/></svg></button>
            <a class="brand" href="<?php echo e(route('supplier.home')); ?>"><?php echo $__env->make('portal.partials.flowtrack-brand', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></a>
        </div>
        <div class="topbar-right">
            <span class="sync-state"><span class="sync-dot"></span>Secure supplier session</span>
            <a class="notification-btn" href="<?php echo e(route('supplier.home')); ?>?view=notifications" aria-label="Notifications"><svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 21h4"/></svg></a>
            <div class="account"><div class="avatar"><?php echo e(strtoupper(mb_substr(request()->user()->name, 0, 1))); ?></div><div class="account-meta"><strong><?php echo e(request()->user()->name); ?></strong><small><?php echo e($company->name); ?></small></div><a class="icon-button" href="<?php echo e(route('supplier.home')); ?>?view=profile" aria-label="Company profile"><svg class="icon-sm" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="m6 9 6 6 6-6"/></svg></a></div>
        </div>
    </header>
    <div class="shell">
        <?php echo $__env->make('portal.partials.sidebar', ['isProductPrices' => true], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <main class="main pricing-main"><div class="content pricing-page pricing-editor-page">
            <header class="page-header pricing-page-header">
                <div><h1>Edit Supplier Prices</h1><p>Submit a change for approval. Your proposed prices will not go live until FlowTracker approves them.</p></div>
                <a class="btn btn-outline-teal pricing-back" href="<?php echo e(route('supplier.products.prices.show', $product->id)); ?>"><svg class="icon-sm" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m12 19-7-7 7-7M5 12h15"/></svg>Back to product</a>
            </header>
            <?php if(session('success')): ?><div class="pricing-alert" role="status"><?php echo e(session('success')); ?></div><?php endif; ?>
            <?php if($errors->any()): ?><div class="pricing-alert pricing-alert--error" role="alert"><?php echo e($errors->first()); ?></div><?php endif; ?>
            <?php ($payload = $product->payload ?? []); ?>
            <?php ($approvedTiers = is_array($payload['supplier_prices'] ?? null) ? $payload['supplier_prices'] : []); ?>
            <?php ($pending = $latest?->status === 'pending'); ?>
            <?php ($displayTiers = $pending ? ($latest->proposed_prices ?? []) : old('tiers', $approvedTiers)); ?>
            <?php ($approvedByQuantity = collect($approvedTiers)->keyBy('quantity')); ?>
            <div class="pricing-editor-grid">
                <div class="pricing-editor-left">
                    <section class="pricing-product-summary">
                        <?php echo $__env->make('portal.partials.pricing-product-image', ['payload' => $payload, 'large' => true], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <div class="pricing-product-summary-text"><div class="pricing-product-heading"><h2><?php echo e($payload['name'] ?? $product->external_reference); ?></h2><span class="pricing-active-badge"><span></span><?php echo e(count($approvedTiers) ? 'Active Price' : 'Awaiting First Price'); ?></span></div><div class="pricing-product-sku"><?php echo e($payload['code'] ?? $product->external_reference); ?></div><div class="pricing-product-timestamp"><?php if($latest?->status === 'approved'): ?>Last approved <?php echo e($latest->updated_at?->diffForHumans()); ?><?php else: ?><?php echo e(count($approvedTiers) ? 'Current approved supplier prices' : 'No approved price tiers yet'); ?><?php endif; ?></div></div>
                    </section>
                    <?php if($latest && $latest->review_note): ?><p class="pricing-review-note" role="status">Latest request: <?php echo e(ucfirst($latest->status)); ?> — <?php echo e($latest->review_note); ?></p><?php endif; ?>
                    <?php if($pending): ?><p class="pricing-pending-note" role="status">Your price request is pending FlowTracker approval. You can review the proposed prices below, but cannot submit another request until it is reviewed. <?php echo e($latest->delivery_status === 'delivered' ? 'FlowTracker has received your request.' : 'Secure delivery will retry automatically.'); ?></p><?php endif; ?>
                    <section class="pricing-editor-card">
                        <header class="pricing-editor-card-header"><h2>Supplier Price Tiers</h2><p>Update your proposed prices for each quantity tier. Enter your new prices below and request approval when ready.</p></header>
                        <form id="supplierPriceEditor" method="post" action="<?php echo e(route('supplier.products.prices.submit', $product->id)); ?>" data-draft-key="supplier-price-draft:<?php echo e((int) $company->id); ?>:<?php echo e((int) $product->id); ?>" data-pending="<?php echo e($pending ? '1' : '0'); ?>" data-baseline-version="<?php echo e($payload['price_version'] ?? ''); ?>" data-has-old="<?php echo e(old('tiers') ? '1' : '0'); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="pricing-tier-scroll"><table class="pricing-edit-table">
                                <thead><tr><th scope="col">Quantity</th><th scope="col">Current Approved Price <span>(USD)</span></th><th scope="col">Proposed New Price <span>(USD)</span></th><th scope="col">Status</th><th scope="col"><span class="sr-only">Remove</span></th></tr></thead>
                                <tbody id="priceTierRows">
                                <?php $__empty_1 = true; $__currentLoopData = $displayTiers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $tier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php ($quantity = (int) ($tier['quantity'] ?? 0)); ?>
                                    <?php ($approved = $approvedByQuantity->get($quantity)); ?>
                                    <?php ($currentPrice = $approved === null ? null : (float) ($approved['price'] ?? 0)); ?>
                                    <tr class="pricing-tier-row" data-baseline="<?php echo e($currentPrice === null ? '' : $currentPrice); ?>">
                                        <td class="pricing-tier-quantity">
                                            <?php if($approved !== null): ?>
                                                <span><?php echo e(number_format($quantity)); ?></span><input class="pricing-quantity-input" type="hidden" name="tiers[<?php echo e($index); ?>][quantity]" value="<?php echo e($quantity); ?>" <?php if($pending): echo 'disabled'; endif; ?>>
                                            <?php else: ?>
                                                <input class="pricing-quantity-input" type="number" name="tiers[<?php echo e($index); ?>][quantity]" min="1" max="100000000" step="1" value="<?php echo e($quantity ?: ''); ?>" aria-label="Quantity for tier <?php echo e($loop->iteration); ?>" <?php if($pending): echo 'disabled'; endif; ?> required>
                                            <?php endif; ?>
                                        </td>
                                        <td class="pricing-current-value"><?php echo e($currentPrice === null ? '—' : '$'.number_format($currentPrice, 2)); ?></td>
                                        <td><input class="pricing-new-price" type="text" inputmode="decimal" name="tiers[<?php echo e($index); ?>][price]" value="<?php echo e($tier['price'] ?? ''); ?>" maxlength="18" pattern="[0-9]+(\.[0-9]{1,6})?" aria-label="Proposed unit price for tier <?php echo e($loop->iteration); ?>" <?php if($pending): echo 'disabled'; endif; ?> required></td>
                                        
                                        <td><span class="pricing-row-status">Unchanged</span></td>
                                        <td><button class="pricing-remove-row" type="button" aria-label="Remove price tier <?php echo e($loop->iteration); ?>" <?php if($pending): echo 'disabled'; endif; ?>><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 7h16m-13 0 1 14h8l1-14M9 7V4h6v3M10 11v7m4-7v7"/></svg></button></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr class="pricing-tier-empty"><td colspan="5">No approved price tiers yet. Add a tier to propose prices.</td></tr>
                                <?php endif; ?>
                                </tbody>
                            </table></div>
                            <?php if (! ($pending)): ?>
                                <button type="button" class="btn btn-outline-teal pricing-add-tier" id="addPriceTier"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M12 7v10M7 12h10"/></svg>Add price tier</button>
                            <?php endif; ?>
                        </form>
                    </section>
                </div>
            </div>
            <div class="pricing-editor-bottom"><a class="btn pricing-cancel" href="<?php echo e(route('supplier.products.prices.show', $product->id)); ?>">Cancel</a><div class="pricing-editor-cta"><span id="pricingDraftStatus" class="pricing-draft-status" role="status" aria-live="polite"></span><?php if (! ($pending)): ?><button type="button" class="btn btn-outline-teal pricing-save" id="savePriceDraft" form="supplierPriceEditor">Save Draft</button><button type="submit" class="btn btn-primary pricing-submit" form="supplierPriceEditor">Request Price Approval</button><?php else: ?><span class="pricing-pill pricing-pill--pending">Pending approval</span><?php endif; ?></div></div>
        </div></main>
    </div>
</section>
<script src="<?php echo e(asset('assets/supplier-pricing.js')); ?>?v=<?php echo e(filemtime(public_path('assets/supplier-pricing.js'))); ?>" defer nonce="<?php echo e(request()->attributes->get('csp_nonce')); ?>"></script>
<script src="<?php echo e(asset('assets/supplier-catalog-realtime.js')); ?>?v=<?php echo e(filemtime(public_path('assets/supplier-catalog-realtime.js'))); ?>" defer nonce="<?php echo e(request()->attributes->get('csp_nonce')); ?>"></script>
<script src="<?php echo e(asset('assets/supplier-mobile.js')); ?>?v=<?php echo e(filemtime(public_path('assets/supplier-mobile.js'))); ?>" defer nonce="<?php echo e(request()->attributes->get('csp_nonce')); ?>"></script>
</body></html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/flowtrack/supplier-portal/resources/views/portal/product-price-edit.blade.php ENDPATH**/ ?>