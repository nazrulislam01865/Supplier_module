<?php
    // Limit supplier presentation only; keep the synchronized workflow unchanged.
    $phases = collect($workflow['stages'] ?? [])->sortBy('sequence')->take(5)->values();
    $activeId = (int) ($workflow['current_phase_id'] ?? 0);
    $selected = $phases->first(fn ($phase) => (int) $phase['id'] === $activeId)
        ?? $phases->first(fn ($phase) => ($phase['state'] ?? '') === 'active')
        ?? $phases->last(fn ($phase) => ($phase['state'] ?? '') === 'completed')
        ?? $phases->first();
    $selectedId = (int) ($selected['id'] ?? 0);
?>
<section class="supplier-flow-original" id="supplierOrderWorkflow" data-supplier-workflow>
    <div class="supplier-flow-process-head">
        <div>
            <h2>Order process &amp; tasks</h2>
            <div class="supplier-flow-sub"><?php echo e($phases->count()); ?> stages · status changes save automatically · conditional tasks appear only when required</div>
        </div>
    </div>
    <?php $__errorArgs = ['workflow'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="supplier-flow-error" role="alert"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <?php if($errors->any() && ! $errors->has('workflow')): ?> <p class="supplier-flow-error" role="alert"><?php echo e($errors->first()); ?></p> <?php endif; ?>
    <?php if(session('success')): ?> <p class="supplier-flow-success" role="status"><?php echo e(session('success')); ?></p> <?php endif; ?>
    <?php if($phases->isEmpty()): ?>
        <div class="supplier-flow-empty">The workflow has not synchronized yet. It will appear after FlowTracker delivers the latest order.</div>
    <?php else: ?>
        <div class="supplier-flow-stages" role="tablist" aria-label="Order workflow stages">
            <?php $__currentLoopData = $phases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $stageState = $stage['state'] ?? 'locked';
                    $isSelected = (int) $stage['id'] === $selectedId;
                    $locked = $stageState === 'locked';
                ?>
                <button type="button" class="supplier-flow-stage <?php echo e($stageState); ?> <?php echo e($isSelected ? 'viewing' : ''); ?>"
                    style="--stage:<?php echo e($stage['color']); ?>"
                    role="tab" id="supplier-flow-tab-<?php echo e((int) $stage['id']); ?>"
                    data-flow-stage="<?php echo e((int) $stage['id']); ?>" aria-controls="supplier-flow-panel-<?php echo e((int) $stage['id']); ?>"
                    aria-disabled="<?php echo e($locked ? 'true' : 'false'); ?>" aria-selected="<?php echo e($isSelected ? 'true' : 'false'); ?>"
                    title="<?php echo e($locked ? ($stage['dependency'] ?? '') : 'Open '.$stage['name'].' tasks'); ?>">
                    <?php if($stageState === 'completed'): ?> <span class="supplier-flow-stage-check">✓</span> <?php endif; ?>
                    <span class="supplier-flow-stage-num">STAGE <?php echo e($stage['sequence']); ?></span>
                    <strong class="supplier-flow-stage-name"><?php echo e($stage['name']); ?></strong>
                    <span class="supplier-flow-stage-state"><?php echo e($stage['state_label']); ?></span>
                    <span class="supplier-flow-progress"><i style="width:<?php echo e((int) $stage['progress']); ?>%"></i></span>
                    <span class="supplier-flow-owner"><span class="supplier-flow-avatar"><?php echo e(mb_substr((string) $stage['owner'], 0, 1)); ?></span> <?php echo e($stage['owner']); ?></span>
                    <span class="supplier-flow-dependency"><?php echo e($stage['dependency']); ?></span>
                </button>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php $__currentLoopData = $phases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <section class="supplier-flow-task-panel" id="supplier-flow-panel-<?php echo e((int) $stage['id']); ?>"
                role="tabpanel" aria-labelledby="supplier-flow-tab-<?php echo e((int) $stage['id']); ?>"
                data-flow-panel="<?php echo e((int) $stage['id']); ?>" <?php if((int) $stage['id'] !== $selectedId): ?> hidden <?php endif; ?>>
                <header class="supplier-flow-task-head">
                    <div>
                        <h3><?php echo e($stage['name']); ?> tasks</h3>
                        <p><?php echo e(match ($stage['state']) { 'completed' => 'This stage is complete', 'active' => 'Complete the active task to continue the workflow', 'cancelled' => 'Order cancelled — workflow actions are blocked', default => 'This stage is locked' }); ?></p>
                    </div>
                    <strong class="supplier-flow-required"><?php echo e((int) $stage['required_complete']); ?> of <?php echo e((int) $stage['required_total']); ?> required complete</strong>
                </header>
                <div class="supplier-flow-table-scroll">
                    <div class="supplier-flow-columns" aria-hidden="true"><span></span><span>Task</span><span>Assignee</span><span>Due date</span><span>Status / files</span><span>Action</span></div>
                    <?php $__empty_1 = true; $__currentLoopData = $stage['tasks']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <article class="supplier-flow-task <?php echo e($task['mode']); ?>" style="--task-color:<?php echo e($stage['color']); ?>">
                            <div class="supplier-flow-task-icon"><?php echo e($task['mode'] === 'done' ? '✓' : ($task['mode'] === 'active' ? '●' : '⌁')); ?></div>
                            <div class="supplier-flow-task-copy">
                                <span class="supplier-flow-task-code">TASK <?php echo e($task['code']); ?></span>
                                <strong><?php echo e($task['title']); ?></strong>
                                <?php if(!$task['required']): ?> <span class="supplier-flow-optional">Optional</span> <?php endif; ?>
                            </div>
                            <div class="supplier-flow-assignee"><span class="supplier-flow-avatar"><?php echo e(mb_substr((string) $task['assignee'], 0, 1)); ?></span> <?php echo e($task['assignee']); ?></div>
                            <div class="supplier-flow-date"><?php echo e(!empty($task['due_date']) ? \Illuminate\Support\Carbon::parse($task['due_date'])->format('M j, Y') : '—'); ?></div>
                            <div class="supplier-flow-task-status"><span class="supplier-flow-pill <?php echo e($task['mode']); ?>"><?php echo e($task['mode'] === 'locked' ? 'Locked' : $task['status']); ?></span></div>
                            <div class="supplier-flow-action">
                                <?php if(($task['can_act'] ?? false) && ($task['assigned_to_supplier'] ?? false)): ?>
                                    <?php
                                        $actionKey = (string) ($task['action_key'] ?? '');
                                        $isUpload = in_array($actionKey, ['NEW_UPLOAD_PO','ART_PREPARE_UPLOAD','ART_SAMPLE_APPROVAL'], true);
                                        $actionText = match ($actionKey) {
                                            'NEW_UPLOAD_PO' => 'Upload Purchase Order',
                                            'NEW_SEND_PO_ARTWORK' => 'Send to Artwork Team',
                                            'ART_PREPARE_UPLOAD' => 'Upload Artwork',
                                            'ART_INTERNAL_REVIEW' => 'Review Artwork',
                                            'ART_SEND_ORDER_TEAM' => 'Send Artwork',
                                            'ART_CLIENT_ERP_DECISION' => str_contains(strtolower((string) $task['status']), 'waiting for client') ? 'Record client decision' : 'Confirm ERP upload',
                                            'ART_SAMPLE_APPROVAL' => 'Upload sample approval',
                                            'PROD_SET_ESTIMATED_DELIVERY' => 'Set date',
                                            'PROD_START' => 'Start production',
                                            'PROD_FINISH' => 'Finish production',
                                            'QC_CHECK' => 'Open QC check',
                                            'QC_APPROVE_SHIPMENT' => 'Approve shipment',
                                            'SHIP_CONFIRM_INFO' => 'Confirm shipment info',
                                            'SHIP_LABEL' => 'Add tracking',
                                            'SHIP_PACKAGE' => 'Dispatch shipment',
                                            default => 'Take action',
                                        };
                                    ?>
                                    <button type="button" class="supplier-flow-action-btn" data-supplier-modal-open="supplier-flow-dialog-<?php echo e((int) $task['id']); ?>"><?php echo e($actionText); ?></button>
                                    <dialog class="supplier-flow-dialog" aria-modal="true" id="supplier-flow-dialog-<?php echo e((int) $task['id']); ?>" aria-labelledby="supplier-flow-dialog-title-<?php echo e((int) $task['id']); ?>" data-supplier-action-dialog>
                                        <div class="supplier-flow-dialog-head">
                                            <div><h4 id="supplier-flow-dialog-title-<?php echo e((int) $task['id']); ?>"><?php echo e($actionKey === 'ART_CLIENT_ERP_DECISION' ? (str_contains(strtolower((string) $task['status']), 'waiting for client') ? 'Record Client Artwork Decision' : 'Confirm Client ERP Upload') : $actionText); ?></h4>
                                            <p>Task <?php echo e($task['code']); ?> · <?php echo e($task['title']); ?></p></div>
                                            <button type="button" class="supplier-flow-dialog-close" data-supplier-modal-close aria-label="Close action dialog">×</button>
                                        </div>
                                        <?php if(old('_supplier_workflow_task') == $task['id'] && $errors->any()): ?>
                                            <p class="supplier-flow-error" role="alert"><?php echo e($errors->first()); ?></p>
                                        <?php endif; ?>
                                        <form method="POST" enctype="multipart/form-data" action="<?php echo e(route('supplier.orders.workflow.action', [$order->id, $task['id']])); ?>" class="supplier-flow-action-form" data-supplier-action-form>
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="_supplier_workflow_task" value="<?php echo e((int) $task['id']); ?>">
                                            <?php if($isUpload): ?>
                                                <input type="hidden" name="decision" value="upload">
                                            <?php elseif($actionKey === 'QC_CHECK'): ?>
                                                <label>Decision <select name="decision"><option value="pass">QC passed</option><option value="issue">Report issue</option></select></label>
                                            <?php elseif(in_array($actionKey, ['PROD_ISSUE','QC_ISSUE'])): ?>
                                                <label>Decision <select name="decision">
                                                    <?php if($actionKey === 'PROD_ISSUE'): ?> <option value="confirm">Complete monitoring</option><option value="issue">Report issue</option> <?php endif; ?>
                                                    <option value="resolve">Resolve issue</option>
                                                </select></label>
                                            <?php elseif($actionKey === 'ART_INTERNAL_REVIEW'): ?>
                                                <label>Decision <select name="decision"><option value="confirm">Artwork confirmed</option><option value="revise">Request revision</option><option value="cancel_artwork">Cancel artwork</option></select></label>
                                            <?php elseif($actionKey === 'ART_CLIENT_ERP_DECISION'): ?>
                                                <?php if(str_contains(strtolower((string) $task['status']), 'waiting for client') || str_contains(strtolower((string) $task['status']), 'client approval')): ?>
                                                    <input type="hidden" name="decision" value="<?php echo e(old('_supplier_workflow_task') == $task['id'] ? old('decision', '') : ''); ?>" data-supplier-client-choice required>
                                                    <div class="supplier-flow-decision-stage" data-client-decision-stage="choice">
                                                        <p class="supplier-flow-helper">Choose the decision received from the client for the latest artwork.</p>
                                                        <div class="supplier-flow-choice-grid">
                                                            <?php if(!empty($task['artwork_files'])): ?>
                                                                <button type="button" class="supplier-flow-choice" data-client-action="revise"><span class="supplier-flow-choice-icon">↻</span><strong>Client Requested Revision</strong><small>Start another artwork revision</small></button>
                                                            <?php endif; ?>
                                                            <button type="button" class="supplier-flow-choice" data-client-action="approved"><span class="supplier-flow-choice-icon">✓</span><strong>Client Approved Artwork</strong><small>Continue to sample decision</small></button>
                                                        </div>
                                                    </div>
                                                    <div class="supplier-flow-decision-stage" data-client-decision-stage="sample" hidden>
                                                        <p class="supplier-flow-helper">Does the client require a sample or swatch before Production?</p>
                                                        <div class="supplier-flow-choice-grid">
                                                            <button type="button" class="supplier-flow-choice" data-client-action="sample"><span class="supplier-flow-choice-icon">✓</span><strong>Sample Required</strong><small>Continue to sample approval</small></button>
                                                            <button type="button" class="supplier-flow-choice" data-client-action="confirm"><span class="supplier-flow-choice-icon">✓</span><strong>No Sample Required</strong><small>Approve artwork and continue</small></button>
                                                        </div>
                                                        <button class="supplier-flow-back" type="button" data-client-back>← Back to decision</button>
                                                    </div>
                                                    <div class="supplier-flow-decision-stage" data-client-decision-stage="revision" hidden>
                                                        <p class="supplier-flow-helper">Select the artwork files needing revision, and describe the changes.</p>
                                                        <?php $__currentLoopData = ($task['artwork_files'] ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artwork): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="supplier-flow-revision-item">
                                                                <label class="supplier-flow-checkbox"><input type="checkbox" name="revision_document_ids[]" value="<?php echo e((int) $artwork['id']); ?>" <?php if(old('_supplier_workflow_task') == $task['id'] && in_array((int) $artwork['id'], array_map('intval', (array) old('revision_document_ids', [])))): echo 'checked'; endif; ?>><span><?php echo e($artwork['name']); ?></span></label>
                                                                <label>Requested change<textarea name="revision_notes[<?php echo e((int) $artwork['id']); ?>]" rows="2" maxlength="2000" placeholder="Describe the correction for this artwork"><?php echo e(old('_supplier_workflow_task') == $task['id'] ? old('revision_notes.'.$artwork['id']) : ''); ?></textarea></label>
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <button class="supplier-flow-back" type="button" data-client-back>← Back to decision</button>
                                                    </div>
                                                <?php else: ?>
                                                    <input type="hidden" name="decision" value="erp_uploaded">
                                                    <p class="supplier-flow-helper">Confirm the artwork has been uploaded to the client ERP. The task will then wait for the client's approval or revision decision.</p>
                                                    <label>ERP reference <span class="supplier-flow-muted">(optional)</span><input name="erp_reference" maxlength="150" value="<?php echo e(old('_supplier_workflow_task') == $task['id'] ? old('erp_reference') : ''); ?>" placeholder="Enter ERP reference"></label>
                                                <?php endif; ?>

                                            <?php elseif($actionKey === 'SHIP_LABEL'): ?>
                                                <input type="hidden" name="decision" value="complete">
                                            <?php else: ?>
                                                <input type="hidden" name="decision" value="confirm">
                                            <?php endif; ?>
                                            <?php if($actionKey === 'PROD_SET_ESTIMATED_DELIVERY'): ?>
                                                <label>Estimated delivery date <input name="estimated_delivery_date" type="date" required></label>
                                            <?php endif; ?>
                                            <?php if($actionKey === 'PROD_ISSUE'): ?>
                                                <label>Supplier delivery date (optional) <input name="supplier_delivery_date" type="date"></label>
                                            <?php endif; ?>
                                            <?php if($actionKey === 'QC_CHECK'): ?>
                                                <div class="supplier-flow-quantities">
                                                    <label>Received <input name="qty_received" type="number" min="0" required></label>
                                                    <label>Inspected <input name="qty_inspected" type="number" min="0" required></label>
                                                    <label>Accepted <input name="qty_accepted" type="number" min="0" value="0"></label>
                                                    <label>Rejected <input name="qty_rejected" type="number" min="0" value="0"></label>
                                                </div>
                                            <?php endif; ?>
                                            <?php if(in_array($actionKey, ['PROD_ISSUE', 'QC_ISSUE'])): ?>
                                                <label>Issue category (optional) <input name="issue_category" maxlength="100"></label>
                                            <?php endif; ?>
                                            <?php if(in_array($actionKey, ['SHIP_LABEL','SHIP_PACKAGE'])): ?>
                                                <label>Shipping provider <input name="carrier" maxlength="150" required></label>
                                                <label>Tracking number <input name="tracking_number" maxlength="150" required></label>
                                                <?php if($actionKey === 'SHIP_PACKAGE'): ?>
                                                    <label>Shipment date <input name="shipment_date" type="date" required></label>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                            <?php if($actionKey === 'SHIP_CONFIRM_INFO'): ?>
                                                <label>Client name <input name="client_name" maxlength="255" required></label>
                                                <label>Contact person <input name="contact_name" maxlength="255" required></label>
                                                <label>Phone country code <input name="phone_country_code" maxlength="50" required></label>
                                                <label>Phone number <input name="phone_number" maxlength="70" required></label>
                                                <label>Shipping address <input name="address" maxlength="500" required></label>
                                                <label>City <input name="city" maxlength="150"></label>
                                                <label>State <input name="state" maxlength="150"></label>
                                                <label>Country <input name="country" maxlength="150" required></label>
                                                <label>Postal code <input name="postal_code" maxlength="40" required></label>
                                            <?php endif; ?>
                                            <?php if($actionKey === 'ART_INTERNAL_REVIEW' && !empty($task['artwork_files'])): ?>
                                                <fieldset>
                                                    <legend>Artwork selection (for revision or cancellation)</legend>
                                                    <?php $__currentLoopData = $task['artwork_files']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artwork): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <label><input type="checkbox" name="revision_document_ids[]" value="<?php echo e((int) $artwork['id']); ?>">
                                                            <?php echo e($artwork['name']); ?></label>
                                                        <label>Requested change (if revising this file)
                                                            <textarea name="revision_notes[<?php echo e((int) $artwork['id']); ?>]" rows="2" maxlength="2000"></textarea>
                                                        </label>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </fieldset>
                                            <?php endif; ?>
                                            <?php if($actionKey === 'ART_PREPARE_UPLOAD' && !empty($task['revision_sources'])): ?>
                                                <?php $__currentLoopData = $task['revision_sources']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $source): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <label>Replace <?php echo e($source['name']); ?>

                                                        <input type="file" name="files[<?php echo e((int) $source['id']); ?>]" required
                                                            accept=".pdf,.doc,.docx,.xls,.xlsx,.jpg,.jpeg,.png,.webp,.gif,.ico,.zip,.txt,.csv,.ai,.eps,.esp,.cdr">
                                                    </label>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <label><?php echo e($isUpload ? 'Upload task files' : 'Attach task evidence (optional)'); ?>

                                                    <input type="file" name="files[]" multiple <?php if($isUpload): ?> required <?php endif; ?>
                                                        accept=".pdf,.doc,.docx,.xls,.xlsx,.jpg,.jpeg,.png,.webp,.gif,.ico,.zip,.txt,.csv,.ai,.eps,.esp,.cdr">
                                                </label>
                                            <?php endif; ?>
                                            <small><?php echo e(in_array($actionKey, ['ART_PREPARE_UPLOAD','ART_SAMPLE_APPROVAL'], true) ? 'Up to 400 MB per file' : 'Up to 20 MB per file'); ?> · max 5 files. Saved in FlowTracker on this task.</small>
                                            <label>Comment <span class="supplier-flow-muted">(optional)</span><textarea name="comment" rows="2" maxlength="2000" placeholder="Add task notes if needed"><?php echo e(old('_supplier_workflow_task') == $task['id'] ? old('comment') : ''); ?></textarea></label>
                                            <div class="supplier-flow-dialog-actions">
                                                <button type="button" class="supplier-flow-cancel" data-supplier-modal-close>Cancel</button>
                                                <button type="submit" class="supplier-flow-action-btn" data-supplier-action-submit><?php echo e($isUpload ? 'Upload and complete task' : ($actionKey === 'ART_CLIENT_ERP_DECISION' ? ((str_contains(strtolower((string) $task['status']), 'waiting for client') || str_contains(strtolower((string) $task['status']), 'client approval')) ? 'Save client decision' : 'Confirm ERP upload') : 'Confirm action')); ?></button>
                                            </div>
                                        </form>
                                    </dialog>
                                <?php elseif(($task['assigned_to_supplier'] ?? false) && $task['mode'] === 'locked'): ?>
                                    <span class="supplier-flow-no-action" title="The previous workflow task or stage must complete before this action can be performed.">Waiting for previous task</span>
                                <?php elseif(($task['assigned_to_supplier'] ?? false) && $task['mode'] === 'done'): ?>
                                    <span class="supplier-flow-no-action">Completed</span>
                                <?php elseif(($task['assigned_to_supplier'] ?? false)): ?>
                                    <span class="supplier-flow-no-action">Managed in FlowTracker</span>
                                <?php else: ?> <span class="supplier-flow-no-action">—</span> <?php endif; ?>
                            </div>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="supplier-flow-empty">No tasks configured for this stage.</div>
                    <?php endif; ?>
                </div>
            </section>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</section>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/flowtrack/supplier-portal/resources/views/portal/partials/workflow.blade.php ENDPATH**/ ?>