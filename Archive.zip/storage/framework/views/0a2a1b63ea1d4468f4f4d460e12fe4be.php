<?php
    $brandName = trim((string) ($company->flowtrack_brand_name ?? '')) ?: 'FlowTrack';
    $brandLogo = $company->flowtrack_brand_logo_url ?? null;
?>
<?php if($brandLogo): ?><img src="<?php echo e($brandLogo); ?>" class="flowtrack-synced-logo" alt="<?php echo e($brandName); ?>" decoding="async"><?php else: ?><span class="brand-mark"><span class="brand-dot"></span></span><?php endif; ?>
<span data-flowtrack-brand-name class="<?php echo \Illuminate\Support\Arr::toCssClasses(['hidden' => filled($brandLogo)]); ?>"><?php echo e($brandName); ?></span>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/flowtrack/supplier-portal/resources/views/portal/partials/flowtrack-brand.blade.php ENDPATH**/ ?>