<?php if($paginator->hasPages()): ?>
<nav role="navigation" aria-label="Product pages" class="pricing-pager-links">
    <?php if($paginator->onFirstPage()): ?><span class="pricing-page-arrow is-disabled" aria-hidden="true">‹</span><?php else: ?><a class="pricing-page-arrow" href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev" aria-label="Previous page">‹</a><?php endif; ?>
    <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(is_string($element)): ?><span class="pricing-page-gap"><?php echo e($element); ?></span><?php else: ?>
            <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($page == $paginator->currentPage()): ?><span class="pricing-page-number is-current" aria-current="page"><?php echo e($page); ?></span>
                <?php else: ?><a class="pricing-page-number" href="<?php echo e($url); ?>" aria-label="Page <?php echo e($page); ?>"><?php echo e($page); ?></a><?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php if($paginator->hasMorePages()): ?><a class="pricing-page-arrow" href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next" aria-label="Next page">›</a><?php else: ?><span class="pricing-page-arrow is-disabled" aria-hidden="true">›</span><?php endif; ?>
</nav>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/flowtrack/supplier-portal/resources/views/portal/partials/pricing-pagination.blade.php ENDPATH**/ ?>