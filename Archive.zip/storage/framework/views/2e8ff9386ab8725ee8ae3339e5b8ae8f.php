<?php
    // The same sidebar is used by the SPA workspace and standalone order details.
    $isOrderDetail = $isOrderDetail ?? false;
    $isProductPrices = $isProductPrices ?? request()->routeIs('supplier.products.prices*');
    $isStandalone = $isOrderDetail || $isProductPrices;
?>
<aside class="sidebar" id="sidebar">
    <div class="nav-section-label">Workspace</div>
    <nav class="nav" aria-label="Supplier workspace">
        <?php if($isStandalone): ?>
            <a class="nav-item" href="<?php echo e(route('supplier.home')); ?>?view=dashboard">
        <?php else: ?>
            <button class="nav-item active" data-view="dashboard" type="button">
        <?php endif; ?>
            <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>
            Dashboard
        <?php if($isStandalone): ?></a><?php else: ?></button><?php endif; ?>

        <?php if($isStandalone): ?>
            <a class="nav-item" href="<?php echo e(route('supplier.home')); ?>?view=quotations">
        <?php else: ?>
            <button class="nav-item" data-view="quotations" type="button">
        <?php endif; ?>
            <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M7 3h8l4 4v14H7z"/><path d="M15 3v5h5M10 13h6M10 17h6M10 9h2"/></svg>
            RFQs <?php if (! ($isStandalone)): ?><span class="nav-count"><?php echo e($quotations->whereIn('status',['open','draft'])->count()); ?></span><?php endif; ?>
        <?php if($isStandalone): ?></a><?php else: ?></button><?php endif; ?>

        <?php if($isStandalone): ?>
            <a class="nav-item <?php echo e($isOrderDetail ? 'active' : ''); ?>" <?php if($isOrderDetail): ?>aria-current="page"<?php endif; ?> href="<?php echo e(route('supplier.home')); ?>?view=orders">
        <?php else: ?>
            <button class="nav-item" data-view="orders" type="button">
        <?php endif; ?>
            <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 7h16v13H4z"/><path d="M8 7V4h8v3M8 11h8"/></svg>
            Orders &amp; Requests <?php if (! ($isStandalone)): ?><span class="nav-count"><?php echo e($orderPage->total()); ?></span><?php endif; ?>
        <?php if($isStandalone): ?></a><?php else: ?></button><?php endif; ?>
        <a class="nav-item <?php echo e($isProductPrices ? 'active' : ''); ?>" href="<?php echo e(route('supplier.products.prices')); ?>" <?php if($isProductPrices): ?>aria-current="page"<?php endif; ?>>
            <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M8 10h8M8 14h5"/></svg>
            Products &amp; Prices
        </a>
    </nav>

    <div class="nav-section-label" style="margin-top:17px">Company</div>
    <nav class="nav" aria-label="Supplier company">
        <?php if($isStandalone): ?><a class="nav-item" href="<?php echo e(route('supplier.home')); ?>?view=profile"><?php else: ?><button class="nav-item" data-view="profile" type="button"><?php endif; ?>
            <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 21h18M5 21V7l7-4 7 4v14M9 21v-5h6v5"/></svg>
            Company Profile
        <?php if($isStandalone): ?></a><?php else: ?></button><?php endif; ?>

        <?php if($isStandalone): ?><a class="nav-item" href="<?php echo e(route('supplier.home')); ?>?view=notifications"><?php else: ?><button class="nav-item" data-view="notifications" type="button"><?php endif; ?>
            <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 21h4"/></svg>
            Notifications <?php if (! ($isStandalone)): ?><span class="nav-count <?php echo e(($dashboard['unreadNotifications'] ?? 0) ? '' : 'hidden'); ?>"><?php echo e($dashboard['unreadNotifications'] ?? 0); ?></span><?php endif; ?>
        <?php if($isStandalone): ?></a><?php else: ?></button><?php endif; ?>
    </nav>

    <div class="nav-section-label" style="margin-top:17px">Support</div>
    <nav class="nav" aria-label="Supplier support">
        <?php if($isStandalone): ?><a class="nav-item" href="<?php echo e(route('supplier.home')); ?>?view=help"><?php else: ?><button class="nav-item" data-view="help" type="button"><?php endif; ?>
            <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="9"/><path d="M9.8 9a2.4 2.4 0 1 1 3.7 2c-.9.5-1.5 1-1.5 2M12 17h.01"/></svg>
            Help &amp; support
        <?php if($isStandalone): ?></a><?php else: ?></button><?php endif; ?>
    </nav>

    <div class="sidebar-bottom">
        <div class="company-mini">
            <small>Signed in as supplier</small>
            <strong><?php echo e($company->name); ?></strong>
            <span><?php echo e($company->flowtrack_short_code ?: $company->reference); ?></span>
            <span><span class="sync-dot" style="width:6px;height:6px;box-shadow:none"></span> Account active</span>
        </div>
    </div>
</aside>
<div class="supplier-mobile-backdrop" aria-hidden="true"></div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/flowtrack/supplier-portal/resources/views/portal/partials/sidebar.blade.php ENDPATH**/ ?>