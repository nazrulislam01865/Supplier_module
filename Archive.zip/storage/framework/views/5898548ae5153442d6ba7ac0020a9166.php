<?php ($product = \App\Services\SupplierDashboardData::class); ?>
<div class="dashboard-hero">
    <div>
        <div class="workspace-pill"><span class="sync-dot" style="box-shadow:none;background:#83e5d2"></span> Supplier workspace</div>
        <h1>Welcome back, <?php echo e($user->name); ?></h1>
        <p>You have <strong style="color:#fff"><?php echo e($rfqActionCount); ?> RFQs requiring attention</strong> and <?php echo e($activeOrderCount); ?> active orders. Your assigned work appears below, prioritized by deadline.</p>
        <div class="dashboard-hero-actions">
            <?php if($priorityRfqs->isNotEmpty()): ?>
                <button class="btn btn-primary btn-sm" type="button" data-open-rfq="<?php echo e($priorityRfqs->first()->id); ?>">Review next action <svg class="icon-sm" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m9 18 6-6-6-6"/></svg></button>
                <button class="btn btn-secondary-hero btn-sm" type="button" data-open-quotations>View all RFQs</button>
            <?php else: ?>
                <button class="btn btn-primary btn-sm" type="button" data-open-quotations>View all RFQs</button>
            <?php endif; ?>
        </div>
    </div>
    <div class="hero-summary">
        <div class="hero-summary-head"><div><small>NEXT RFQ DEADLINE</small><strong><?php echo e($nextDeadline?->due_at?->format('M j, Y') ?? 'No upcoming deadline'); ?></strong></div><?php if($nextDeadline): ?><span class="time-chip"><?php echo e($nextDeadline->due_at->format('M j')); ?></span><?php endif; ?></div>
        <div class="hero-summary-product">
            <div class="product-thumb"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4"><path d="M5 9c4-2 10-2 14 0v7c-4 2-10 2-14 0V9Z"/><path d="M8 11h8M8 14h8"/></svg></div>
            <div><strong><?php echo e($nextDeadline ? $product::product($nextDeadline) : 'No pending RFQ deadlines'); ?></strong><span><?php echo e($nextDeadline?->external_reference ?? 'You are up to date'); ?></span></div>
        </div>
        <div class="hero-summary-foot"><span>Supplier workspace</span><span><?php echo e($nextDeadline ? 'Awaiting quotation' : 'No deadlines pending'); ?></span></div>
    </div>
</div>
<div class="stats supplier-dashboard-stats">
    <div class="stat-card"><div class="stat-icon"><svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M7 3h8l4 4v14H7z"/><path d="M15 3v5h5"/></svg></div><div class="stat-text"><small>RFQs needing action</small><strong><?php echo e($rfqActionCount); ?></strong><span>Open or draft quotations</span></div><span class="stat-chip attn"><?php echo e($rfqActionCount); ?> action<?php echo e($rfqActionCount === 1 ? '' : 's'); ?></span></div>
    <div class="stat-card"><div class="stat-icon"><svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 7h16v13H4z"/><path d="M8 7V4h8v3M8 11h8"/></svg></div><div class="stat-text"><small>Active orders</small><strong><?php echo e($activeOrderCount); ?></strong><span>Orders shared by FlowTrack</span></div></div>
    <div class="stat-card"><div class="stat-icon"><svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M5 12l4 4L19 6"/></svg></div><div class="stat-text"><small>Submitted this month</small><strong><?php echo e($submittedMonthCount); ?></strong><span>Submitted quotations</span></div></div>
</div>
<div class="dashboard-grid">
    <div class="card">
        <div class="card-header"><div><h2>RFQs requiring action</h2><p>Prioritized by deadline</p></div><button class="btn btn-ghost btn-sm" type="button" data-open-quotations>View all</button></div>
        <div class="card-body priority-list" id="priorityList">
            <?php $__empty_1 = true; $__currentLoopData = $priorityRfqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rfq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="priority-item <?php echo e($rfq->due_at?->isPast() ? 'urgent' : 'open'); ?>">
                    <div class="priority-main"><div class="product-thumb">RFQ</div><div><strong class="item-title"><?php echo e($product::product($rfq)); ?></strong><div class="item-ref"><?php echo e($rfq->external_reference); ?></div><div class="item-meta"><?php echo e($rfq->due_at ? ($rfq->due_at->isPast() ? 'Overdue' : 'Due').' '.$rfq->due_at->format('M j, Y') : 'No deadline'); ?> · <?php echo e(ucfirst($rfq->status)); ?></div></div></div>
                    <div class="priority-actions"><button type="button" class="btn btn-primary btn-sm" data-open-rfq="<?php echo e($rfq->id); ?>"><?php echo e($rfq->status === 'draft' ? 'Continue draft' : 'Review request'); ?></button></div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="empty-state" style="padding:20px">No RFQs require action right now.</div>
            <?php endif; ?>
        </div>
    </div>
    <div style="display:grid;gap:16px;align-content:start">
        <div class="card">
            <div class="card-header"><div><h2>Upcoming deadlines</h2><p>Upcoming quotation due dates</p></div></div>
            <div class="card-body deadline-list">
                <?php $__empty_1 = true; $__currentLoopData = $upcomingDeadlines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rfq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <button class="status-line supplier-dashboard-link" type="button" data-open-rfq="<?php echo e($rfq->id); ?>"><span><strong><?php echo e($rfq->external_reference); ?></strong><span><?php echo e($product::product($rfq)); ?></span></span><strong><?php echo e($rfq->due_at->format('M j')); ?></strong></button>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="empty-state"><p>No upcoming RFQ deadlines.</p></div>
                <?php endif; ?>
            </div>
        </div>
        <div class="card">
            <div class="card-header"><div><h2>Recent activity</h2><p>Latest RFQ and order changes</p></div></div>
            <div class="card-body recent-list">
                <?php $__empty_1 = true; $__currentLoopData = $recentActivity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php if($entry->type === 'rfq'): ?>
                        <button type="button" class="status-line supplier-dashboard-link" data-open-rfq="<?php echo e($entry->id); ?>"><span><strong><?php echo e($entry->external_reference); ?> · <?php echo e(ucfirst($entry->status)); ?></strong><span><?php echo e($product::product($entry)); ?></span></span><small><?php echo e($entry->updated_at?->diffForHumans()); ?></small></button>
                    <?php else: ?>
                        <a class="status-line supplier-dashboard-link" href="<?php echo e($product::link($entry)); ?>"><span><strong><?php echo e($entry->external_reference); ?> · <?php echo e(data_get($entry->payload, 'order_status', 'Order updated')); ?></strong><span><?php echo e($product::product($entry)); ?></span></span><small><?php echo e($entry->updated_at?->diffForHumans()); ?></small></a>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="empty-state"><p>No RFQ or order activity received yet.</p></div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/flowtrack/supplier-portal/resources/views/portal/partials/dashboard.blade.php ENDPATH**/ ?>