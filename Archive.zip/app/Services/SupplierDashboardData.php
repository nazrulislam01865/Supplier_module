<?php

namespace App\Services;

use App\Models\SupplierQuotation;
use App\Models\SupplierResource;
use App\Models\SupplierUser;

/** Dashboard projections from the local, signed, supplier-scoped bridge records. */
final class SupplierDashboardData
{
    public function forUser(SupplierUser $user): array
    {
        $companyId = (int) $user->supplier_company_id;
        $base = SupplierResource::query()->where('supplier_company_id', $companyId);
        $actionable = (clone $base)->where('type', 'rfq')->whereIn('status', ['open', 'draft'])
            ->where(fn ($query) => $query->whereNull('due_at')->orWhere('due_at', '>=', now()));
        $priority = (clone $actionable)->orderByRaw('CASE WHEN due_at IS NULL THEN 1 ELSE 0 END')
            ->orderBy('due_at')->limit(5)->get(['id', 'external_reference', 'status', 'payload', 'due_at']);
        $deadlines = $priority->filter(fn (SupplierResource $row) => $row->due_at !== null)->values();
        $next = $deadlines->first();
        $notifications = (clone $base)->whereIn('type', ['rfq', 'order'])
            ->where('status', '!=', 'revoked')->latest('updated_at')->latest('id')->limit(20)
            ->get(['id', 'type', 'external_reference', 'status', 'payload', 'updated_at']);
        $readAt = $user->notifications_read_at;
        $unread = (clone $base)->whereIn('type', ['rfq', 'order'])
            ->where('status', '!=', 'revoked')
            ->when($readAt, fn ($query) => $query->where('updated_at', '>', $readAt))
            ->count();

        return [
            'rfqActionCount' => (clone $actionable)->count(),
            'activeOrderCount' => (clone $base)->where('type', 'order')->where('status', '!=', 'revoked')->count(),
            'submittedMonthCount' => SupplierQuotation::query()->where('supplier_company_id', $companyId)
                ->where('status', 'submitted')->where('submitted_at', '>=', now()->startOfMonth())
                ->where('submitted_at', '<', now()->startOfMonth()->addMonth())->count(),
            'nextDeadline' => $next,
            'priorityRfqs' => $priority,
            'upcomingDeadlines' => $deadlines,
            'recentActivity' => $notifications->take(6),
            'notifications' => $notifications,
            'unreadNotifications' => $unread,
        ];
    }

    public static function product(SupplierResource $resource): string
    {
        $payload = $resource->payload ?? [];
        return (string) ($payload['product_name'] ?? $payload['title'] ?? ('Order '.$resource->external_reference));
    }

    public static function link(SupplierResource $resource): string
    {
        if ($resource->type === 'order') return route('supplier.orders.show', $resource->id);
        return route('supplier.home', ['view' => 'quotations', 'rfq' => $resource->id]);
    }
}
