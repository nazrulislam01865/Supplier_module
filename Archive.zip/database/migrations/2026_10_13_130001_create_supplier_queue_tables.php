<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up(): void {
        if (! Schema::hasTable('supplier_delivery_jobs')) Schema::create('supplier_delivery_jobs', function (Blueprint $table): void {
            $table->id(); $table->string('queue')->index(); $table->longText('payload');
            $table->unsignedTinyInteger('attempts'); $table->unsignedInteger('reserved_at')->nullable();
            $table->unsignedInteger('available_at'); $table->unsignedInteger('created_at');
            $table->index(['queue', 'reserved_at']);
        });
        if (! Schema::hasTable('supplier_failed_jobs')) Schema::create('supplier_failed_jobs', function (Blueprint $table): void {
            $table->id(); $table->string('uuid')->unique(); $table->text('connection');
            $table->text('queue'); $table->longText('payload'); $table->longText('exception');
            $table->timestamp('failed_at')->useCurrent();
        });
    }
    public function down(): void {
        Schema::dropIfExists('supplier_failed_jobs'); Schema::dropIfExists('supplier_delivery_jobs');
    }
};
