@php($product = \App\Services\SupplierDashboardData::class)
@forelse($notifications as $notice)
    @php($new = ! $user->notifications_read_at || $notice->updated_at->gt($user->notifications_read_at))
    @if($notice->type === 'rfq')
        <button type="button" class="notice supplier-notice-link {{ $new ? 'supplier-notice-new' : '' }}" data-open-rfq="{{ $notice->id }}">
            <span class="notice-icon">RFQ</span><span><strong>{{ $notice->external_reference }} · {{ ucfirst($notice->status) }}</strong><span>{{ $product::product($notice) }}</span><time>{{ $notice->updated_at->diffForHumans() }}</time></span>
        </button>
    @else
        <a class="notice supplier-notice-link {{ $new ? 'supplier-notice-new' : '' }}" href="{{ $product::link($notice) }}">
            <span class="notice-icon">ORD</span><span><strong>{{ $notice->external_reference }} · {{ data_get($notice->payload, 'order_status', 'Order updated') }}</strong><span>{{ $product::product($notice) }}</span><time>{{ $notice->updated_at->diffForHumans() }}</time></span>
        </a>
    @endif
@empty
    <div class="empty-state"><h3>No notifications</h3><p>Assigned RFQ and order updates will appear here.</p></div>
@endforelse
