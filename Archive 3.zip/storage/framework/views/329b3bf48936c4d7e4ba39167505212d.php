<div class="supplier-orders-table-viewport">
    <table class="supplier-orders-table">
        <thead><tr>
            <th>Order</th><th>Product</th><th>Current Stage</th><th>Status</th><th>Supplier Delivery Date</th><th>Progress</th>
        </tr></thead>
        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
                $detailsUrl = route('supplier.orders.show', $order['id']);
                $rowAccent = $order['hold'] ? '#FF6A00' : $order['stage_color'];
            ?>
            <tr class="supplier-order-row <?php echo e($order['hold'] ? 'is-on-hold' : ''); ?>" style="--supplier-order-accent:<?php echo e($rowAccent); ?>" data-supplier-order-href="<?php echo e($detailsUrl); ?>" tabindex="0" aria-label="Open order <?php echo e($order['reference']); ?>">
                <td data-label="Order">
                    <a class="supplier-order-ref" href="<?php echo e($detailsUrl); ?>"><?php echo e($order['reference']); ?></a>
                    <?php if($order['is_redo']): ?><span class="supplier-redo-badge">Redo order</span><?php endif; ?>
                    <span class="supplier-order-subline"><?php echo e($order['created']); ?></span>
                    <a class="supplier-order-po-link" href="<?php echo e(route('supplier.purchase-orders.show', $order['id'])); ?>">Purchase Orders</a>
                    <?php if($order['hold']): ?><span class="supplier-order-hold-label">Ⅱ On Hold</span><?php endif; ?>
                </td>
                <td data-label="Product">
                    <div class="supplier-order-product-cell">
                        <span class="supplier-order-product-avatar" aria-hidden="true">P</span>
                        <div class="supplier-order-product-copy"><strong title="<?php echo e($order['products']); ?>"><?php echo e($order['products'] ?: 'Product not specified'); ?></strong></div>
                    </div>
                </td>
                <td data-label="Current Stage"><span class="supplier-order-stage" style="--supplier-order-stage:<?php echo e($order['stage_color']); ?>"><span class="supplier-order-stage-dot"></span><?php echo e($order['stage']); ?></span></td>
                <td data-label="Status"><span class="supplier-order-status <?php echo e($order['hold'] ? 'is-held' : ''); ?>"><?php echo e($order['status']); ?></span><?php if($order['hold']): ?><small class="supplier-order-flag">On hold</small><?php endif; ?></td>
                <td data-label="Supplier Delivery Date"><span class="supplier-order-delivery-date"><?php echo e($order['supplier_delivery'] ?: 'Not set'); ?></span></td>
                <td data-label="Progress"><div class="supplier-order-progress"><span class="supplier-order-progress-track"><span style="width:<?php echo e($order['progress'] ?? 0); ?>%"></span></span><strong><?php echo e($order['progress'] === null ? '—' : $order['progress'].'%'); ?></strong></div></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td class="supplier-orders-empty" colspan="6"><strong>No matching orders</strong><span>Change the search or filters to see your assigned orders.</span></td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/Supplier_module/resources/views/portal/partials/orders/table.blade.php ENDPATH**/ ?>