<?php if($perm('supplier_pricing')): ?>
<div class="ft-product-supplier-price-list">
  <div class="ft-product-price-section-header"><strong>Supplier-based price tables (1)</strong></div>
  <small>Each tagged supplier has its own quantity-based cost table. Approved supplier requests appear here automatically. Supplier costs do not affect client selling prices.</small>
  <div class="ft-product-client-price-entry ft-native-supplier-edit-card">
    <strong><?php echo e($company->name); ?></strong>
  <?php if($perm('supplier_pricing','edit')): ?><form action="<?php echo e(route('supplier.products.module.action')); ?>" method="POST"><?php echo csrf_field(); ?>
    <input type="hidden" name="operation" value="save_pricing"><input type="hidden" name="group" value="product"><input type="hidden" name="id" value="<?php echo e($recordId); ?>"><input type="hidden" name="section" value="supplier_pricing"><input type="hidden" name="base_version" value="<?php echo e($price['version'] ?? ''); ?>"><input type="hidden" name="charges_version" value="<?php echo e($price['charges_version'] ?? ''); ?>">
    <label class="ft-product-field" style="margin:12px 0;max-width:280px"><span>Supplier price currency</span><select name="currency">
      <?php $__currentLoopData = $currencies->isNotEmpty() ? $currencies : collect([['code'=>'USD','name'=>'USD'],['code'=>'CNY','name'=>'CNY']]); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($currency['code']); ?>" <?php if(($price['currency'] ?? 'USD') === $currency['code']): echo 'selected'; endif; ?>><?php echo e($currency['code']); ?> — <?php echo e($currency['name']); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select></label>
    <div class="ft-product-matrix-toolbar"><small>Enter the quantity in the first row and supplier unit price below it. Surcharges and shipment charges are optional per quantity.</small></div>
    <?php echo $__env->make('portal.product-native.matrix', ['section'=>'supplier_pricing','rows'=>$price['rows'] ?? [],'charges'=>$price['charges'] ?? [],'editable'=>true,'title'=>'Supplier pricing'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="ft-native-form-actions"><button type="submit" class="ft-native-btn is-primary">Save supplier pricing</button></div>
  </form><?php else: ?>
<?php if(!empty($price['rows'])): ?>
<?php echo $__env->make('portal.product-native.matrix', ['section'=>'supplier_pricing','rows'=>$price['rows'] ?? [],'charges'=>$price['charges'] ?? [],'editable'=>false,'title'=>'Supplier pricing'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php else: ?><p class="ft-price-empty-state">No quantity-based prices configured for this currency.</p><?php endif; ?>
<?php endif; ?>
  <?php if(!empty($price['additional_tables'])): ?><div class="ft-price-additional-heading">Additional currency tables</div><?php endif; ?>
  <?php $__currentLoopData = ($price['additional_tables'] ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $extraTable): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo $__env->make('portal.product-native.supplier-currency-table', [
        'extraTable' => $extraTable, 'editable' => $perm('supplier_pricing','edit'),
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php if($perm('supplier_pricing','edit')): ?>
    <details class="ft-supplier-currency-add ft-price-currency" style="margin-top:2px">
      <summary class="ft-price-currency-heading"><span class="ft-price-currency-identity"><strong>+ Add currency table</strong></span><span class="ft-price-currency-meta">Choose a currency and quantities<span class="ft-price-chevron" aria-hidden="true"></span></span></summary>
      <div class="ft-price-currency-body">
      <form method="POST" action="<?php echo e(route('supplier.products.module.action')); ?>" style="margin-top:14px">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="operation" value="save_pricing">
        <input type="hidden" name="group" value="product">
        <input type="hidden" name="id" value="<?php echo e($recordId); ?>">
        <input type="hidden" name="section" value="supplier_currency_table">
        <input type="hidden" name="base_version" value="<?php echo e($price['new_table_version'] ?? ''); ?>">
        <label class="ft-product-field" style="display:block;max-width:300px;margin-bottom:14px">
          <span>Supplier price currency</span>
          <select name="currency" required>
            <option value="">Select currency</option>
            <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($currency['code'] !== ($price['currency'] ?? 'USD') &&
                  !collect($price['additional_tables'] ?? [])->contains('currency', $currency['code'])): ?>
                <option value="<?php echo e($currency['code']); ?>"><?php echo e($currency['code']); ?> — <?php echo e($currency['name']); ?></option>
              <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </label>
        <?php echo $__env->make('portal.product-native.matrix', [
            'section'=>'supplier_pricing', 'rows'=>[], 'charges'=>[], 'editable'=>true,
            'title'=>'New supplier currency table',
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <div class="ft-native-form-actions"><button class="ft-product-page-btn is-primary" type="submit">Save currency table</button></div>
      </form>
      </div>
    </details>
  <?php endif; ?>
  </div>
</div>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/Supplier_module/resources/views/portal/product-native/sections/supplier_pricing.blade.php ENDPATH**/ ?>