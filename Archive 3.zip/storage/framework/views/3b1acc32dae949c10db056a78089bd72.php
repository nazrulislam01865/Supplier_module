<?php
    $faviconHref = $brandFavicon ?? ($company->flowtrack_brand_favicon_url ?? null);
?>
<?php if($faviconHref): ?>
    <link rel="icon" href="<?php echo e($faviconHref); ?>">
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/Supplier_module/resources/views/portal/partials/flowtrack-favicon.blade.php ENDPATH**/ ?>