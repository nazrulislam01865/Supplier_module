<?php if($perm('shipment')): ?>
<?php
    $remotePrices = $shipment['remote_surcharge'] ?? [];
    $urgencyEntries = $shipment['urgencies'] ?? [];
    $urgencyOptions = $lookups['shipment_urgencies'] ?? [];
    $canEditShipment = $perm('shipment', 'edit');
?>
<div class="ft-native-section ft-ux-shipment-workspace">
    <div class="ft-ux-section-intro">
        <div>
            <h3>Shipment &amp; surcharge</h3>
            <p>Configure quantity-based remote area charges and available shipping urgencies.</p>
        </div>
        <?php if (! ($canEditShipment)): ?><span class="ft-ux-readonly-pill">View only</span><?php endif; ?>
    </div>

    <?php if($canEditShipment): ?>
    <form method="POST" action="<?php echo e(route('supplier.products.module.action')); ?>">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="operation" value="save_pricing">
        <input type="hidden" name="group" value="product">
        <input type="hidden" name="id" value="<?php echo e($recordId); ?>">
        <input type="hidden" name="section" value="shipment">
    <?php endif; ?>

    <div class="ft-ux-subsection">
        <div class="ft-ux-subsection-heading">
            <div>
                <h3>Remote area surcharge prices</h3>
                <p>Extra charge per unit at the specified quantity.</p>
            </div>
            <span class="ft-ux-counter"><?php echo e(count($remotePrices)); ?> <?php echo e(count($remotePrices) === 1 ? 'tier' : 'tiers'); ?></span>
        </div>
        <?php if(empty($remotePrices)): ?>
            <div class="ft-ux-empty-panel">
                <span class="ft-ux-empty-icon" aria-hidden="true">＋</span>
                <div>
                    <strong>No remote area surcharges configured</strong>
                    <small><?php echo e($canEditShipment ? 'Enter a quantity and charge below, or leave these fields empty if this product has no surcharge.' : 'No quantity-based remote area surcharge prices have been set for this product.'); ?></small>
                </div>
            </div>
        <?php endif; ?>
        <?php if($canEditShipment || !empty($remotePrices)): ?>
            <?php echo $__env->make('portal.product-native.matrix', ['section'=>'client_pricing', 'rows'=>$remotePrices, 'editable'=>$canEditShipment, 'title'=>'Remote area surcharge prices', 'fieldPrefix'=>'remote_surcharge'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endif; ?>
    </div>

    <div class="ft-ux-subsection">
        <div class="ft-ux-subsection-heading">
            <div>
                <h3>Shipping urgencies</h3>
                <p>Available shipment speeds and their additional charges.</p>
            </div>
            <span class="ft-ux-counter"><?php echo e(count($urgencyEntries)); ?> selected</span>
        </div>
        <?php if(empty($urgencyEntries)): ?>
            <div class="ft-ux-empty-panel">
                <span class="ft-ux-empty-icon" aria-hidden="true">↗</span>
                <div>
                    <strong>No shipping urgencies added</strong>
                    <small><?php echo e($canEditShipment ? 'Use Add shipping urgency to select one of the available options.' : 'No urgency options are configured for this product.'); ?></small>
                </div>
            </div>
        <?php endif; ?>
        <?php if($canEditShipment): ?>
            <div class="ft-native-repeat ft-ux-urgency-repeat" data-repeat="urgencies">
                <div class="ft-native-repeat-items ft-ux-urgency-list">
                    <?php $__currentLoopData = $urgencyEntries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $urgency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="ft-native-repeat-row ft-ux-urgency-row">
                            <label><span>Shipping urgency</span>
                                <select name="urgencies[<?php echo e($i); ?>][shipment_urgency_id]" required>
                                    <?php $__currentLoopData = $urgencyOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($option['id']); ?>" <?php if((int) ($urgency['shipment_urgency_id'] ?? 0) === (int) $option['id']): echo 'selected'; endif; ?>><?php echo e($option['name']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </label>
                            <label><span>Additional charge</span><input type="number" step="0.01" min="0" name="urgencies[<?php echo e($i); ?>][extra_charge]" value="<?php echo e($urgency['extra_charge'] ?? 0); ?>" required placeholder="0.00"></label>
                            <button type="button" class="ft-ux-row-remove" data-native-remove-row aria-label="Remove shipping urgency">Remove</button>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <button type="button" class="ft-product-page-btn is-secondary ft-ux-add-urgency" data-native-add-row <?php if(empty($urgencyOptions)): echo 'disabled'; endif; ?>>+ Add shipping urgency</button>
                <?php if(empty($urgencyOptions)): ?><small class="ft-ux-muted-note">No shipping urgency options are available in FlowTracker master data.</small><?php endif; ?>
                <template>
                    <div class="ft-native-repeat-row ft-ux-urgency-row">
                        <label><span>Shipping urgency</span>
                            <select name="urgencies[__INDEX__][shipment_urgency_id]" required>
                                <?php $__currentLoopData = $urgencyOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($option['id']); ?>"><?php echo e($option['name']); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </label>
                        <label><span>Additional charge</span><input type="number" step="0.01" min="0" name="urgencies[__INDEX__][extra_charge]" value="0" required placeholder="0.00"></label>
                        <button type="button" class="ft-ux-row-remove" data-native-remove-row aria-label="Remove shipping urgency">Remove</button>
                    </div>
                </template>
            </div>
        <?php else: ?>
            <?php if(!empty($urgencyEntries)): ?>
                <div class="ft-ux-urgency-summary">
                    <?php $__currentLoopData = $urgencyEntries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $urgency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="ft-ux-urgency-summary-row">
                            <strong><?php echo e($urgency['shipment_urgency_name'] ?? 'Shipping urgency'); ?></strong>
                            <span>Additional charge: <?php echo e(number_format((float) ($urgency['extra_charge'] ?? 0), 2)); ?></span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
    <?php if($canEditShipment): ?>
        <div class="ft-ux-section-actions">
            <small>Saving updates only this product's shipment settings.</small>
            <button type="submit" class="ft-product-page-btn is-primary">Save shipment settings</button>
        </div>
    <?php else: ?>
        <p class="ft-ux-permission-note">Shipment settings are read-only for your supplier account. Editing requires Shipment → Edit permission in FlowTracker.</p>
    <?php endif; ?>
    <?php if($canEditShipment): ?></form><?php endif; ?>
</div>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/Supplier_module/resources/views/portal/product-native/sections/shipment.blade.php ENDPATH**/ ?>