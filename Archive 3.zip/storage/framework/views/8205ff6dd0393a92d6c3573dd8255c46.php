<?php
    // The same sidebar is used by the SPA workspace and standalone order details.
    $isOrderDetail = $isOrderDetail ?? false;
    $isProductPrices = $isProductPrices ?? request()->routeIs('supplier.products.prices*');
    $isProductModule = $isProductModule ?? request()->routeIs('supplier.products.module');
    $isPurchaseOrders = $isPurchaseOrders ?? request()->routeIs('supplier.purchase-orders.*');
    $isStandalone = $isOrderDetail || $isProductPrices || $isPurchaseOrders || $isProductModule;
    $initialView = $initialView ?? 'dashboard';
    $unreadCount = $isStandalone ? ($sidebarCounts['unread'] ?? 0) : ($dashboard['unreadNotifications'] ?? 0);
?>
<aside class="sidebar" id="sidebar">
    <div class="nav-section-label">Workspace</div>
    <nav class="nav" aria-label="Supplier workspace">
        <?php if($isStandalone): ?>
            <a class="nav-item" href="<?php echo e(route('supplier.home')); ?>?view=dashboard">
        <?php else: ?>
            <button class="nav-item <?php echo e($initialView === 'dashboard' ? 'active' : ''); ?>" data-view="dashboard" type="button">
        <?php endif; ?>
            <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>
            Dashboard
        <?php if($isStandalone): ?></a><?php else: ?></button><?php endif; ?>

        <?php if($isStandalone): ?>
            <a class="nav-item" href="<?php echo e(route('supplier.home')); ?>?view=quotations">
        <?php else: ?>
            <button class="nav-item <?php echo e($initialView === 'quotations' ? 'active' : ''); ?>" data-view="quotations" type="button">
        <?php endif; ?>
            <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M7 3h8l4 4v14H7z"/><path d="M15 3v5h5M10 13h6M10 17h6M10 9h2"/></svg>
            RFQs <span class="nav-count"><?php echo e($isStandalone ? ($sidebarCounts['rfqs'] ?? 0) : $quotations->whereIn('status',['open','draft'])->count()); ?></span>
        <?php if($isStandalone): ?></a><?php else: ?></button><?php endif; ?>

        <?php if($isStandalone): ?>
            <a class="nav-item <?php echo e($isOrderDetail ? 'active' : ''); ?>" <?php if($isOrderDetail): ?>aria-current="page"<?php endif; ?> href="<?php echo e(rtrim(route('supplier.home'), '/').'/'); ?>?view=orders">
        <?php else: ?>
            <button class="nav-item <?php echo e($initialView === 'orders' ? 'active' : ''); ?>" data-view="orders" type="button">
        <?php endif; ?>
            <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 7h16v13H4z"/><path d="M8 7V4h8v3M8 11h8"/></svg>
            Orders &amp; Requests <span class="nav-count"><?php echo e($isStandalone ? ($sidebarCounts['orders'] ?? 0) : $orderPage->total()); ?></span>
        <?php if($isStandalone): ?></a><?php else: ?></button><?php endif; ?>
        <a class="nav-item <?php echo e($isPurchaseOrders ? 'active' : ''); ?>" href="<?php echo e(route('supplier.purchase-orders.index')); ?>" <?php if($isPurchaseOrders): ?>aria-current="page"<?php endif; ?>>
            <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M7 3h8l4 4v14H7z"/><path d="M15 3v5h4M10 13h6M10 17h6"/><path d="M5 8H3v13h12"/></svg>
            Purchase Orders
        </a>
        <div class="supplier-product-nav-group" aria-label="Product">
            <div class="nav-section-label" style="margin-top:12px">Product</div>
            <?php $__currentLoopData = [
                ['product', false, 'Products'],
                ['product', true, 'Create Product'],
                ['product_category', false, 'Product Categories'],
                ['product_category', true, 'Create Product Category'],
            ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$productGroup, $productCreate, $productLabel]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="nav-item <?php echo e($isProductModule && ($group ?? request()->query('group', 'product')) === $productGroup && ($create ?? request()->query('create') === '1') == $productCreate ? 'active' : ''); ?>"
                    href="<?php echo e(route('supplier.products.module', ['group' => $productGroup] + ($productCreate ? ['create' => '1'] : []))); ?>"
                    <?php if($isProductModule && ($group ?? request()->query('group', 'product')) === $productGroup && ($create ?? request()->query('create') === '1') == $productCreate): ?> aria-current="page" <?php endif; ?>>
                    <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true">
                        <?php if($productCreate): ?><circle cx="12" cy="12" r="9"/><path d="M12 7v10M7 12h10"/><?php else: ?><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M8 10h8M8 14h8"/><?php endif; ?>
                    </svg>
                    <?php echo e($productLabel); ?>

                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <a class="nav-item <?php echo e($isProductPrices ? 'active' : ''); ?>" href="<?php echo e(route('supplier.products.prices')); ?>" <?php if($isProductPrices): ?>aria-current="page"<?php endif; ?>>
            <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M8 10h8M8 14h5"/></svg>
            Products &amp; Prices
        </a>
    </nav>

    <div class="nav-section-label" style="margin-top:17px">Company</div>
    <nav class="nav" aria-label="Supplier company">
        <?php if($isStandalone): ?><a class="nav-item" href="<?php echo e(route('supplier.home')); ?>?view=profile"><?php else: ?><button class="nav-item <?php echo e($initialView === 'profile' ? 'active' : ''); ?>" data-view="profile" type="button"><?php endif; ?>
            <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 21h18M5 21V7l7-4 7 4v14M9 21v-5h6v5"/></svg>
            Company Profile
        <?php if($isStandalone): ?></a><?php else: ?></button><?php endif; ?>

        <?php if($isStandalone): ?><a class="nav-item" href="<?php echo e(route('supplier.home')); ?>?view=notifications"><?php else: ?><button class="nav-item <?php echo e($initialView === 'notifications' ? 'active' : ''); ?>" data-view="notifications" type="button"><?php endif; ?>
            <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 21h4"/></svg>
            Notifications <span class="nav-count <?php echo e($unreadCount ? '' : 'hidden'); ?>"><?php echo e($unreadCount); ?></span>
        <?php if($isStandalone): ?></a><?php else: ?></button><?php endif; ?>
    </nav>

    <div class="nav-section-label" style="margin-top:17px">Support</div>
    <nav class="nav" aria-label="Supplier support">
        <?php if($isStandalone): ?><a class="nav-item" href="<?php echo e(route('supplier.home')); ?>?view=help"><?php else: ?><button class="nav-item <?php echo e($initialView === 'help' ? 'active' : ''); ?>" data-view="help" type="button"><?php endif; ?>
            <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="9"/><path d="M9.8 9a2.4 2.4 0 1 1 3.7 2c-.9.5-1.5 1-1.5 2M12 17h.01"/></svg>
            Help &amp; support
        <?php if($isStandalone): ?></a><?php else: ?></button><?php endif; ?>
    </nav>

    <div class="sidebar-bottom">
        <div class="company-mini">
            <small>Signed in as supplier</small>
            <strong><?php echo e($company->name); ?></strong>
            <span><?php echo e($company->flowtrack_short_code ?: $company->reference); ?></span>
            <span><span class="sync-dot" style="width:6px;height:6px;box-shadow:none"></span> Account active</span>
        </div>
        <form method="POST" action="<?php echo e(route('supplier.logout')); ?>" class="supplier-sidebar-logout-form">
            <?php echo csrf_field(); ?>
            <button class="nav-item supplier-sidebar-logout" type="submit">
                <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M10 17l5-5-5-5M15 12H3"/><path d="M12 3h6a3 3 0 0 1 3 3v12a3 3 0 0 1-3 3h-6"/></svg>
                Log out
            </button>
        </form>
    </div>
</aside>
<div class="supplier-mobile-backdrop" aria-hidden="true"></div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/Supplier_module/resources/views/portal/partials/sidebar.blade.php ENDPATH**/ ?>