<?php
    $hasOrderFilters = $orderFilters['search'] !== '' || $orderFilters['hold'] || $orderFilters['stage'] || $orderFilters['quick'] !== ''
        || $orderFilters['from'] !== '' || $orderFilters['to'] !== '';
?>
<div class="supplier-orders-list" id="supplierOrdersList">
    <?php echo $__env->make('portal.partials.orders.filters', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="supplier-orders-list-summary" role="status">
        <span><?php echo e(number_format($orderPage->total())); ?> orders</span>
        <span><?php echo e($orderFilters['quick'] === 'today' ? 'Created Today filter' : ($orderFilters['quick'] === 'completed' ? 'Supplier completed filter' : ($orderFilters['stage'] ? ($orderStages[$orderFilters['stage']] ?? 'Stage').' filter' : 'Showing all workflow stages'))); ?></span>
    </div>
    <?php echo $__env->make('portal.partials.orders.table', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('portal.partials.orders.pagination', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/Supplier_module/resources/views/portal/partials/orders/list.blade.php ENDPATH**/ ?>