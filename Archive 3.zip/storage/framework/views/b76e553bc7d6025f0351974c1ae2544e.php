<?php if(data_get($permissions, 'availability.view', false)): ?>
    <?php
        $availability = $product['availability'] ?? [];
        $availabilityMode = (string) ($availability['mode'] ?? 'all');
        $canEditAvailability = $edit && (bool) data_get($permissions, 'availability.edit', false);
        $selectedClients = array_map('intval', $availability['client_ids'] ?? []);
    ?>
    <div class="ft-product-client-scope" data-native-availability>
        <span class="ft-product-field-title">Client availability</span>
        <div class="ft-product-radio-row">
            <label><input type="radio" name="mode" form="supplier-native-availability-form" value="all" <?php if($availabilityMode !== 'specific'): echo 'checked'; endif; ?> <?php if(!$canEditAvailability): echo 'disabled'; endif; ?>> All clients</label>
            <label><input type="radio" name="mode" form="supplier-native-availability-form" value="specific" <?php if($availabilityMode === 'specific'): echo 'checked'; endif; ?> <?php if(!$canEditAvailability): echo 'disabled'; endif; ?>> Selected clients</label>
        </div>
        <div class="ft-native-availability-client-list" <?php if($availabilityMode !== 'specific'): ?> hidden <?php endif; ?>>
            <?php if($canEditAvailability): ?>
                <label class="ft-product-field"><span>Select clients</span>
                    <select name="client_ids[]" form="supplier-native-availability-form" multiple size="4" aria-label="Available clients">
                        <?php $__currentLoopData = ($lookups['clients'] ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($client['id']); ?>" <?php if(in_array((int) $client['id'], $selectedClients, true)): echo 'selected'; endif; ?>><?php echo e($client['name']); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </label>
            <?php else: ?>
                <div class="ft-product-client-badges">
                    <?php $__currentLoopData = ($availability['labels'] ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><span><?php echo e($label); ?></span><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>
        <?php if($canEditAvailability): ?>
            <button type="submit" form="supplier-native-availability-form" class="ft-product-page-btn is-secondary">Save availability</button>
        <?php elseif(! $edit): ?>
            <small class="ft-product-help">Save the product first to manage client availability.</small>
        <?php endif; ?>
    </div>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/Supplier_module/resources/views/portal/product-native/product-form-availability.blade.php ENDPATH**/ ?>