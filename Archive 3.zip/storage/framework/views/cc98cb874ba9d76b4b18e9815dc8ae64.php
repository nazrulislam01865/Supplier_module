<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php echo $__env->make('portal.partials.flowtrack-favicon', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <title>Product · FlowTrack Supplier Portal</title>
    <link rel="stylesheet" href="<?php echo e(asset('assets/supplier.css')); ?>?v=<?php echo e(filemtime(public_path('assets/supplier.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/supplier-mobile.css')); ?>?v=<?php echo e(filemtime(public_path('assets/supplier-mobile.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/supplier-product-module.css')); ?>?v=<?php echo e(filemtime(public_path('assets/supplier-product-module.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/flowtracker-product-parity.css')); ?>?v=<?php echo e(filemtime(public_path('assets/flowtracker-product-parity.css'))); ?>">
    <?php if($group === 'product_category'): ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/flowtracker-product-categories.css')); ?>?v=<?php echo e(filemtime(public_path('assets/flowtracker-product-categories.css'))); ?>">
    <?php endif; ?>
</head>
<body>
<section id="portalView" class="supplier-product-module-page">
    <header class="topbar">
        <div class="topbar-left">
            <button class="btn btn-ghost btn-sm mobile-menu" id="mobileMenuBtn" type="button" aria-label="Open menu"><svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 7h16M4 12h16M4 17h16"/></svg></button>
            <a class="brand" href="<?php echo e(route('supplier.home')); ?>?view=dashboard"><?php echo $__env->make('portal.partials.flowtrack-brand', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></a>
        </div>
        <div class="topbar-right"><span class="sync-state"><span class="sync-dot"></span>Secure API connection</span>
            <div class="account"><div class="avatar"><?php echo e(mb_strtoupper(mb_substr($user->name,0,1))); ?></div><div class="account-meta"><strong><?php echo e($user->name); ?></strong><small><?php echo e($company->name); ?></small></div></div>
        </div>
    </header>
    <div class="shell">
        <?php echo $__env->make('portal.partials.sidebar', ['isProductModule' => true], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <main class="main supplier-product-module-main" id="productNativeMain">
            <div class="ft-native-product ft-master-page">
                <?php if(session('success')): ?><div class="ft-native-alert is-success" role="status"><?php echo e(session('success')); ?></div><?php endif; ?>
                <?php if($errors->any()): ?><div class="ft-native-alert is-danger" role="alert"><?php echo e($errors->first()); ?></div><?php endif; ?>
                <?php if($moduleError): ?>
                    <div class="supplier-product-module-error" role="alert"><h2>Product API connection unavailable</h2><p><?php echo e($moduleError); ?></p><a class="ft-native-btn is-primary" href="<?php echo e(route('supplier.products.module', ['group' => $group] + ($create ? ['create'=>1] : []))); ?>">Retry connection</a></div>
                <?php elseif($group === 'product_category'): ?>
                    <?php echo $__env->make('portal.product-native.categories', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php elseif($create || $edit): ?>
                    <?php echo $__env->make('portal.product-native.product-form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php elseif($id > 0): ?>
                    <?php echo $__env->make('portal.product-native.product-detail', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php else: ?>
                    <?php echo $__env->make('portal.product-native.products', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endif; ?>
            </div>
        </main>
    </div>
</section>
<script src="<?php echo e(asset('assets/supplier-product-module.js')); ?>?v=<?php echo e(filemtime(public_path('assets/supplier-product-module.js'))); ?>" defer></script>
<script src="<?php echo e(asset('assets/supplier-mobile.js')); ?>?v=<?php echo e(filemtime(public_path('assets/supplier-mobile.js'))); ?>" defer></script>
<script src="<?php echo e(asset('assets/supplier-session.js')); ?>?v=<?php echo e(filemtime(public_path('assets/supplier-session.js'))); ?>" data-activity-url="<?php echo e(route('supplier.session.activity')); ?>" data-logout-url="<?php echo e(route('supplier.logout')); ?>" data-login-url="<?php echo e(route('supplier.login')); ?>" defer></script>
</body></html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/Supplier_module/resources/views/portal/product-module.blade.php ENDPATH**/ ?>