<?php if($perm('options')): ?>
<div class="ft-product-options-workspace">
    <?php if($perm('options', 'edit')): ?>
        <form method="POST" action="<?php echo e(route('supplier.products.module.action')); ?>">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="operation" value="save_pricing"><input type="hidden" name="group" value="product"><input type="hidden" name="id" value="<?php echo e($recordId); ?>"><input type="hidden" name="section" value="options">
            <div class="ft-native-repeat ft-product-options-list" data-repeat="options">
                <div class="ft-native-repeat-items">
                    <?php $__currentLoopData = ($product['options'] ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="ft-native-repeat-row ft-product-option-row">
                            <input type="hidden" name="options[<?php echo e($i); ?>][key]" value="<?php echo e($option['key']); ?>">
                            <label class="ft-product-field ft-product-option-label-field"><span>Label <i>*</i></span><input name="options[<?php echo e($i); ?>][label]" value="<?php echo e($option['label']); ?>" required maxlength="140" placeholder="e.g. Red, Large, Cotton"></label>
                            <label class="ft-product-field ft-product-option-charge-field"><span>Extra charge <em>Optional</em></span><input name="options[<?php echo e($i); ?>][extra_charge]" type="number" min="0" step="0.01" value="<?php echo e($option['extra_charge']); ?>" placeholder="0.00"></label>
                            <div class="ft-product-field ft-product-option-image-field"><span>Image <em>Optional</em></span><div class="ft-product-option-image-input">
                                <?php if($option['has_image'] ?? false): ?><img src="<?php echo e(route('supplier.products.module.asset', ['product'=>$recordId,'kind'=>'option_image','option_key'=>$option['key']])); ?>" alt="<?php echo e($option['label']); ?>"><?php else: ?><span class="ft-product-option-image-placeholder">No image</span><?php endif; ?>
                            </div></div>
                            <button type="button" class="ft-product-option-remove" data-native-remove-row>Remove</button>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <button type="button" class="ft-product-option-add" data-native-add-row>+ Add option</button>
                <template><div class="ft-native-repeat-row ft-product-option-row">
                    <label class="ft-product-field ft-product-option-label-field"><span>Label <i>*</i></span><input name="options[__INDEX__][label]" required maxlength="140" placeholder="e.g. Red, Large, Cotton"></label>
                    <label class="ft-product-field ft-product-option-charge-field"><span>Extra charge <em>Optional</em></span><input name="options[__INDEX__][extra_charge]" type="number" min="0" step="0.01" value="0" placeholder="0.00"></label>
                    <div class="ft-product-field ft-product-option-image-field"><span>Image <em>Optional</em></span><div class="ft-product-option-image-input"><span class="ft-product-option-image-placeholder">No image</span></div></div>
                    <button type="button" class="ft-product-option-remove" data-native-remove-row>Remove</button>
                </div></template>
            </div>
            <div class="ft-native-form-actions"><button class="ft-product-page-btn is-primary" type="submit">Save product options</button></div>
        </form>
        <?php $__currentLoopData = ($product['options'] ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="ft-native-option-image">
                <strong><?php echo e($option['label']); ?> — Image</strong>
                <form method="POST" action="<?php echo e(route('supplier.products.module.action')); ?>" enctype="multipart/form-data"><?php echo csrf_field(); ?>
                    <input type="hidden" name="operation" value="upload_asset"><input type="hidden" name="group" value="product"><input type="hidden" name="id" value="<?php echo e($recordId); ?>"><input type="hidden" name="kind" value="option_image"><input type="hidden" name="option_key" value="<?php echo e($option['key']); ?>">
                    <input type="file" name="file" required accept="image/png,image/jpeg,image/webp">
                    <button type="submit" class="ft-product-page-btn is-secondary">Update option image</button>
                </form>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <div class="ft-product-options-list">
            <?php $__empty_1 = true; $__currentLoopData = ($product['options'] ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="ft-product-option-detail-row"><strong><?php echo e($option['label']); ?></strong>
                    <div class="ft-product-option-detail-charge"><small>Extra charge</small><span><?php echo e(number_format((float) ($option['extra_charge'] ?? 0), 2)); ?></span></div>
                    <div class="ft-product-option-detail-image"><?php if($option['has_image'] ?? false): ?>
                        <img src="<?php echo e(route('supplier.products.module.asset', ['product'=>$recordId,'kind'=>'option_image','option_key'=>$option['key']])); ?>" alt="<?php echo e($option['label']); ?>">
                    <?php else: ?><span>No image</span><?php endif; ?></div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <small>No product options added.</small>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/Supplier_module/resources/views/portal/product-native/sections/options.blade.php ENDPATH**/ ?>