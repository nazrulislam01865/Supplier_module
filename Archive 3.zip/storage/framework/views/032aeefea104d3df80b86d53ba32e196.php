<?php
    $product = $details ?: [];
    $categories = collect($lookups['categories'] ?? []);
    $productCategories = $categories->where('type','product_category');
    $mainCategories = $categories->where('type','product_main_category');
    $formId = $edit ? ($product['id'] ?? 0) : 0;
    $canSaveProduct = ! $edit || (bool) data_get($permissions, 'products.edit', false);
    $productFieldDisabled = $canSaveProduct ? '' : 'disabled';
?>
<div class="ft-product-page ft-product-form-page ft-form-standard ft-form-standard--product">
    <div class="ft-product-page-breadcrumb">
        <a href="<?php echo e(route('supplier.products.module', ['group'=>'product'])); ?>">Products</a>
        <span>/</span><strong><?php echo e($edit ? 'Edit product' : 'Create product'); ?></strong>
    </div>
    <header class="ft-product-form-header">
        <div>
            <h1><?php echo e($edit ? 'Edit product' : 'Create product'); ?></h1>
            <p><?php echo e($edit ? 'Update the product information, linked suppliers, availability and supporting documents.' : 'Add a product and link its category, suppliers, image and supporting documents.'); ?></p>
        </div>
        <?php if($edit && $canSaveProduct): ?>
            <div class="ft-product-form-top-actions">
                <a class="ft-product-page-btn is-secondary" href="<?php echo e(route('supplier.products.module', ['group'=>'product','id'=>$formId])); ?>">Cancel</a>
                <button class="ft-product-page-btn is-primary" type="submit" form="supplier-native-product-form">Save changes</button>
            </div>
        <?php endif; ?>
    </header>
    <?php if($edit && data_get($permissions, 'availability.edit', false)): ?>
        <form id="supplier-native-availability-form" method="POST" action="<?php echo e(route('supplier.products.module.action')); ?>">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="operation" value="save_pricing"><input type="hidden" name="group" value="product"><input type="hidden" name="id" value="<?php echo e($formId); ?>"><input type="hidden" name="section" value="availability">
        </form>
    <?php endif; ?>
    <?php if($edit && data_get($permissions, 'documents.edit', false)): ?>
        <form id="supplier-native-image-upload" method="POST" action="<?php echo e(route('supplier.products.module.action')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="operation" value="upload_asset"><input type="hidden" name="group" value="product"><input type="hidden" name="id" value="<?php echo e($formId); ?>"><input type="hidden" name="kind" value="image">
        </form>
    <?php endif; ?>
    <div class="ft-product-form-shell">
    <form id="supplier-native-product-form" method="POST" action="<?php echo e(route('supplier.products.module.action')); ?>">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="operation" value="save_product">
        <input type="hidden" name="group" value="product">
        <input type="hidden" name="id" value="<?php echo e($formId); ?>">
        <section class="ft-product-page-section">
            <div class="ft-product-page-section-heading"><span class="ft-product-page-section-number">1</span><div><h2>Product information</h2></div></div>
            <div class="ft-product-page-section-body">
                <div class="ft-product-form-info-grid">
                    <div class="ft-product-form-fields">
                        <div class="ft-form-grid ft-form-grid-3">
                            <label class="ft-product-field"><span>Product code</span><div class="ft-product-locked-field"><?php echo e($product['display_code'] ?? 'Generated after creation'); ?> <span>⌑</span></div><small>Generated automatically after the product is created.</small></label>
                            <label class="ft-product-field"><span>Reference product code <em>Optional</em></span><input <?php if(!$canSaveProduct): echo 'disabled'; endif; ?> name="reference_code" maxlength="120" value="<?php echo e(old('reference_code', $product['reference_code'] ?? '')); ?>" placeholder="Client or supplier reference"><small>Client or supplier reference used for search and matching.</small></label>
                            <label class="ft-product-field"><span>Product name <i>*</i></span><input <?php if(!$canSaveProduct): echo 'disabled'; endif; ?> name="name" required maxlength="240" value="<?php echo e(old('name', $product['name'] ?? '')); ?>" placeholder="Enter product name"></label>
                        </div>
                        <div class="ft-product-field ft-product-default-supplier"><span>Default supplier <em>Assigned</em></span><div class="ft-product-locked-field"><?php echo e($company->flowtrack_short_code ?: $company->name); ?></div><small>This product remains assigned to your supplier account in FlowTracker.</small></div>
                        <div class="ft-product-field ft-product-linked-suppliers"><span>Linked suppliers</span><div class="ft-product-locked-field"><?php echo e($company->flowtrack_short_code ?: $company->name); ?></div><small>A supplier can view and edit only products that FlowTracker has tagged to its account.</small></div>
                        <label class="ft-product-field ft-product-size-field"><span>Product size</span><textarea <?php if(!$canSaveProduct): echo 'disabled'; endif; ?> name="size" rows="4" placeholder="Add size/specification details. Use a new line for each item, e.g. width, finished length, material, capacity or dimensions."><?php echo e(old('size', $product['size'] ?? '')); ?></textarea><small>Enter multiple size/specification details on separate lines so the information stays easy to read.</small></label>
                        <?php echo $__env->make('portal.product-native.product-form-availability', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <input type="hidden" name="description" value="<?php echo e(old('description', $product['description'] ?? '')); ?>">
                        <input type="hidden" name="status" value="<?php echo e(old('status', $product['status'] ?? 'active')); ?>">
                    </div>
                    <div class="ft-product-image-column">
                        <span class="ft-product-field-title">Product image <em>Optional</em></span>
                        <div class="ft-product-image-drop ft-native-image-preview" <?php if($edit && data_get($permissions, 'documents.edit', false)): ?> data-native-image-drop <?php endif; ?>>
                            <?php if($edit && ($product['has_image'] ?? false) && data_get($permissions, 'documents.view')): ?>
                                <img src="<?php echo e(route('supplier.products.module.asset', ['product'=>$formId,'kind'=>'image'])); ?>" alt="<?php echo e($product['name']); ?>">
                            <?php else: ?>
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" width="32" height="32" aria-hidden="true"><rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="8" cy="9" r="2"/><path d="m3 17 6-6 4 4 3-3 5 5"/></svg>
                                <strong><?php echo e($edit && data_get($permissions, 'documents.edit', false) ? 'Drop image or browse' : 'No image'); ?></strong>
                            <?php endif; ?>
                        </div>
                        <?php if($edit && data_get($permissions, 'documents.edit', false)): ?>
                            <div class="ft-ux-image-upload-actions">
                                <label class="ft-product-field ft-native-image-input"><span>Choose image</span><input type="file" name="file" form="supplier-native-image-upload" id="supplierNativeImageFile" accept="image/png,image/jpeg,image/webp" required></label>
                                <button type="submit" form="supplier-native-image-upload" class="ft-product-page-btn is-secondary">Upload image</button>
                            </div>
                        <?php endif; ?>
                        <small class="ft-product-help">PNG, JPG or WEBP · Max 5 MB<?php echo e(!$edit ? ' · Save the product before uploading.' : ''); ?></small>
                    </div>
                </div>
            </div>
        </section>
        <section class="ft-product-page-section">
            <div class="ft-product-page-section-heading"><span class="ft-product-page-section-number">2</span><div><h2>Category hierarchy</h2><p>Select from top to bottom. Each list is filtered by the selection above.</p></div></div>
            <div class="ft-product-page-section-body">
                <div class="ft-form-grid ft-form-grid-3">
                    <label class="ft-product-field"><span>Main category</span><select <?php if(!$canSaveProduct): echo 'disabled'; endif; ?> id="nativeProductMainCategory" aria-label="Main category"><option value="">Select main category</option><?php $__currentLoopData = $mainCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($category['id']); ?>" <?php if((int) ($productCategories->firstWhere('id', (int) ($product['parent_id'] ?? 0))['main_category_id'] ?? 0) === (int) $category['id']): echo 'selected'; endif; ?>><?php echo e($category['name']); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></label>
                    <label class="ft-product-field"><span>Product category</span><select <?php if(!$canSaveProduct): echo 'disabled'; endif; ?> name="parent_id" id="nativeProductCategory"><option value="">Select category</option><?php $__currentLoopData = $productCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($category['id']); ?>" data-main-id="<?php echo e($category['main_category_id'] ?? 0); ?>" <?php if((int) old('parent_id', $product['parent_id'] ?? 0) === (int) $category['id']): echo 'selected'; endif; ?>><?php echo e($category['name']); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></label>
                    <label class="ft-product-field"><span>Subcategory</span><input <?php if(!$canSaveProduct): echo 'disabled'; endif; ?> name="sub_category" maxlength="200" value="<?php echo e(old('sub_category', $product['sub_category'] ?? '')); ?>" placeholder="Optional subcategory"></label>
                </div>
            </div>
        </section>
    </form>
    <?php if($edit): ?>
        <?php echo $__env->make('portal.product-native.product-form-extra-sections', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php else: ?>
        <?php $__currentLoopData = ['3'=>'Product pricing', '4'=>'Product options', '5'=>'Shipping urgencies', '6'=>'Supporting documents']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $number => $heading): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <section class="ft-product-page-section">
                <div class="ft-product-page-section-heading"><span class="ft-product-page-section-number"><?php echo e($number); ?></span><div><h2><?php echo e($heading); ?></h2></div></div>
                <div class="ft-product-page-section-body"><small>Save the product first to manage this section through the secure FlowTracker API.</small></div>
            </section>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <footer class="ft-product-form-bottom-actions ft-ux-product-form-footer">
        <small><?php echo e($edit ? 'Product information and category are saved here. Shipment settings and document uploads have separate save actions.' : 'Required fields are marked with an asterisk.'); ?></small>
        <div class="ft-ux-footer-buttons">
            <a class="ft-product-page-btn is-secondary" href="<?php echo e(route('supplier.products.module', $formId ? ['group'=>'product','id'=>$formId] : ['group'=>'product'])); ?>">Cancel</a>
            <?php if($canSaveProduct): ?>
                <button class="ft-product-page-btn is-primary" type="submit" form="supplier-native-product-form"><?php echo e($edit ? 'Save changes' : 'Create product'); ?></button>
            <?php endif; ?>
        </div>
    </footer>
    </div>
</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/Supplier_module/resources/views/portal/product-native/product-form.blade.php ENDPATH**/ ?>