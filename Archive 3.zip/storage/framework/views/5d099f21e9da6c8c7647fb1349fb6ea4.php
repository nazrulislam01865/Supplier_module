<?php ($product = \App\Services\SupplierDashboardData::class); ?>
<?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <?php ($new = ! $user->notifications_read_at || $notice->updated_at->gt($user->notifications_read_at)); ?>
    <?php ($isRfq = $notice->type === 'rfq'); ?>
    <?php if($isRfq): ?>
        <button type="button" class="notice supplier-notice-link <?php echo e($new ? 'supplier-notice-new' : ''); ?>" data-notice-type="rfq" data-notice-unread="<?php echo e($new ? '1' : '0'); ?>" data-open-rfq="<?php echo e($notice->id); ?>">
    <?php else: ?>
        <a class="notice supplier-notice-link <?php echo e($new ? 'supplier-notice-new' : ''); ?>" data-notice-type="order" data-notice-unread="<?php echo e($new ? '1' : '0'); ?>" href="<?php echo e($product::link($notice)); ?>">
    <?php endif; ?>
        <span class="notice-icon <?php echo e($isRfq ? 'notice-icon-rfq' : 'notice-icon-order'); ?>" aria-hidden="true">
            <?php if($isRfq): ?>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M5 3.5h10l4 4V20H5zM15 3.5V8h4M8 12h8M8 16h6"/></svg>
            <?php else: ?>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3.5 7.5 12 3l8.5 4.5v9L12 21l-8.5-4.5zM3.5 7.5 12 12l8.5-4.5M12 12v9"/></svg>
            <?php endif; ?>
        </span>
        <span class="notice-content">
            <span class="notice-heading">
                <strong><?php echo e($notice->external_reference); ?></strong>
                <?php if($new): ?><span class="notice-unread-dot" aria-label="Unread notification"></span><?php endif; ?>
            </span>
            <span class="notice-product"><?php echo e($product::product($notice)); ?></span>
            <span class="notice-meta">
                <span class="notice-status"><?php echo e($isRfq ? ucfirst($notice->status) : data_get($notice->payload, 'order_status', 'Order updated')); ?></span>
                <time datetime="<?php echo e($notice->updated_at->toIso8601String()); ?>" title="<?php echo e($notice->updated_at->format('M j, Y g:i A')); ?>"><?php echo e($notice->updated_at->diffForHumans()); ?></time>
            </span>
        </span>
        <span class="notice-arrow" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m9 5 7 7-7 7"/></svg></span>
    <?php if($isRfq): ?>
        </button>
    <?php else: ?>
        </a>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="notice-empty-base">
        <span class="notice-empty-symbol" aria-hidden="true">✓</span>
        <strong>No updates yet</strong>
        <p>RFQ and order activity will appear here.</p>
    </div>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/Supplier_module/resources/views/portal/partials/notifications.blade.php ENDPATH**/ ?>