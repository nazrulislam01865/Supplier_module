<?php if($perm('client_pricing')): ?>
<div class="ft-product-client-price-list"><div class="ft-product-price-section-header"><strong>Client price tables (<?php echo e(count($clientPrice['client_rows'] ?? []) ?: 1); ?>)</strong></div><small>One quantity-based selling-price table applies to all clients. Supplier costs remain separate.</small>
  <div class="ft-native-price-label">All clients · <?php echo e($clientPrice['currency'] ?? 'USD'); ?></div>
  <?php if($perm('client_pricing','edit')): ?><form method="post" action="<?php echo e(route('supplier.products.module.action')); ?>"><?php echo csrf_field(); ?>
    <input type="hidden" name="operation" value="save_pricing"><input type="hidden" name="group" value="product"><input type="hidden" name="id" value="<?php echo e($recordId); ?>"><input type="hidden" name="section" value="client_pricing">
    <label class="ft-product-field" style="display:block;max-width:280px;margin:12px 0"><span>Client price currency</span><select name="currency"><?php $__currentLoopData = $currencies->isNotEmpty() ? $currencies : collect([['code'=>'USD','name'=>'USD'],['code'=>'CNY','name'=>'CNY']]); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($currency['code']); ?>" <?php if(($clientPrice['currency'] ?? 'USD') === $currency['code']): echo 'selected'; endif; ?>><?php echo e($currency['code']); ?> — <?php echo e($currency['name']); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></label>
    <div class="ft-product-matrix-toolbar"><small>Enter quantities in the first row and corresponding client unit prices below.</small></div>
    <?php echo $__env->make('portal.product-native.matrix', ['section'=>'client_pricing','rows'=>$clientPrice['rows'] ?? [],'editable'=>true,'title'=>'All clients price table'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="ft-native-form-actions"><button class="ft-native-btn is-primary">Save client pricing</button></div>
  </form><?php else: ?>
<?php echo $__env->make('portal.product-native.matrix', ['section'=>'client_pricing','rows'=>$clientPrice['rows'] ?? [],'editable'=>false,'title'=>'All clients price table'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php endif; ?>
  <?php if(($clientPrice['client_rows'] ?? []) !== []): ?>
   <div class="ft-native-subsection"><h3>Selected-client price overrides</h3>
    <?php $__currentLoopData = $clientPrice['client_rows']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $over): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="ft-native-price-label"><?php echo e(collect($lookups['clients'] ?? [])->firstWhere('id', $over['client_id'])['name'] ?? ('Client #'.$over['client_id'])); ?> · <?php echo e($over['currency'] ?? 'USD'); ?></div>
      <?php if($perm('client_pricing','edit')): ?>
       <form method="post" action="<?php echo e(route('supplier.products.module.action')); ?>"><?php echo csrf_field(); ?>
        <input type="hidden" name="operation" value="save_pricing"><input type="hidden" name="group" value="product"><input type="hidden" name="id" value="<?php echo e($recordId); ?>"><input type="hidden" name="section" value="client_override">
        <input type="hidden" name="client_id" value="<?php echo e($over['client_id']); ?>"><input type="hidden" name="base_version" value="<?php echo e($over['version']); ?>">
        <?php echo $__env->make('portal.product-native.matrix', ['section'=>'client_pricing','rows'=>$over['rows'] ?? [],'editable'=>true,'title'=>'Selected client price override'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <div class="ft-native-form-actions">
          <label class="ft-native-currency"><span>Currency</span><select name="currency">
            <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($currency['code']); ?>" <?php if(($over['currency'] ?? 'USD') === $currency['code']): echo 'selected'; endif; ?>><?php echo e($currency['code']); ?> — <?php echo e($currency['name']); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select></label>
          <button class="ft-native-btn is-primary" type="submit">Save client override</button>
          <button class="ft-native-btn is-danger" type="submit" name="remove" value="1" onclick="return confirm('Remove this selected-client pricing table?')">Remove override</button>
        </div>
       </form>
      <?php else: ?>
       <?php echo $__env->make('portal.product-native.matrix', ['section'=>'client_pricing','rows'=>$over['rows'] ?? [],'editable'=>false,'title'=>'Client price override'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
      <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </div>
  <?php endif; ?>
  <?php if($perm('client_pricing','edit')): ?>
    <div class="ft-native-subsection"><h3>Add selected-client price table</h3>
     <form method="POST" action="<?php echo e(route('supplier.products.module.action')); ?>"><?php echo csrf_field(); ?>
      <input type="hidden" name="operation" value="save_pricing"><input type="hidden" name="group" value="product"><input type="hidden" name="id" value="<?php echo e($recordId); ?>"><input type="hidden" name="section" value="client_override">
      <div class="ft-native-grid ft-native-grid-2"><label><span>Client</span><select name="client_id" required><option value="">Select client</option>
      <?php $__currentLoopData = ($lookups['clients'] ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($client['id']); ?>"><?php echo e($client['name']); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select></label>
      <label><span>Currency</span><select name="currency"><?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($currency['code']); ?>" <?php if($currency['code'] === ($clientPrice['currency'] ?? 'USD')): echo 'selected'; endif; ?>><?php echo e($currency['code']); ?> — <?php echo e($currency['name']); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></label></div>
      <?php echo $__env->make('portal.product-native.matrix', ['section'=>'client_pricing','rows'=>[],'editable'=>true,'title'=>'New client price override'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
      <div class="ft-native-form-actions"><button class="ft-native-btn is-primary" type="submit">Save selected-client prices</button></div>
     </form>
    </div>
  <?php endif; ?>
</div>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/Supplier_module/resources/views/portal/product-native/sections/client_pricing.blade.php ENDPATH**/ ?>