
<?php if(count($orderStageCards)): ?>
    <section class="supplier-order-stages" aria-label="Supplier orders by workflow stage">
        <div class="supplier-order-stage-grid">
            <?php $__currentLoopData = $orderStageCards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $isQuick = $stage['kind'] === 'quick';
                    $selected = $isQuick
                        ? $orderFilters['quick'] === $stage['quick']
                        : $orderFilters['quick'] === '' && $orderFilters['stage'] === $stage['sequence'];
                    $query = array_filter([
                        'view' => 'orders',
                        'search' => $orderFilters['search'],
                        'hold' => $orderFilters['hold'] ? '1' : '',
                        'stage' => $isQuick || $selected ? '' : $stage['sequence'],
                        'quick' => $isQuick && !$selected ? $stage['quick'] : '',
                        'from' => $orderFilters['from'],
                        'to' => $orderFilters['to'],
                    ], static fn ($value) => $value !== '');
                    $label = $isQuick ? $stage['name'] : $stage['name'].' stage';
                ?>
                <a href="<?php echo e(rtrim(route('supplier.home'), '/').'/'); ?>?<?php echo e(http_build_query($query)); ?>"
                   class="supplier-order-stage-card <?php echo e($selected ? 'is-selected' : ''); ?>"
                   style="--supplier-stage:<?php echo e($stage['color']); ?>"
                   aria-label="<?php echo e($selected ? 'Clear' : 'Filter by'); ?> <?php echo e($label); ?>, <?php echo e(number_format($stage['count'])); ?> <?php echo e($stage['count'] === 1 ? 'order' : 'orders'); ?>"
                   <?php if($selected): ?> aria-current="true" <?php endif; ?>>
                    <?php if($selected): ?><span class="supplier-order-stage-check" aria-hidden="true">✓</span><?php endif; ?>
                    <span class="supplier-order-stage-kicker"><?php echo e($isQuick ? $stage['kicker'] : 'Stage '.$stage['sequence']); ?></span>
                    <strong class="supplier-order-stage-name"><?php echo e($stage['name']); ?></strong>
                    <span class="supplier-order-stage-bottom">
                        <span><?php echo e($isQuick ? 'Current filters' : 'Current orders'); ?></span>
                        <b><?php echo e(number_format($stage['count'])); ?></b>
                    </span>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/Supplier_module/resources/views/portal/partials/orders/stage-cards.blade.php ENDPATH**/ ?>