<div class="supplier-orders-pagination">
    <span>
        <?php if($orderPage->total()): ?>
            Showing <?php echo e($orderPage->firstItem()); ?>–<?php echo e($orderPage->lastItem()); ?> of <?php echo e(number_format($orderPage->total())); ?> orders
        <?php else: ?>
            Showing 0 of 0 orders
        <?php endif; ?>
    </span>
    <?php
        $current = $orderPage->currentPage();
        $last = $orderPage->lastPage();
        $pageNumbers = collect([1, max(1, $current - 1), $current, min($last, $current + 1), $last])->unique()->sort()->values();
    ?>
    <nav class="supplier-orders-page-controls" aria-label="Order pages">
        <?php if($orderPage->onFirstPage()): ?>
            <span class="supplier-orders-page-button is-disabled" aria-disabled="true" aria-label="Previous page">←</span>
        <?php else: ?>
            <a class="supplier-orders-page-button" href="<?php echo e($orderPage->previousPageUrl()); ?>" aria-label="Previous page">←</a>
        <?php endif; ?>
        <?php $__currentLoopData = $pageNumbers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $number): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a class="supplier-orders-page-button <?php echo e($current === $number ? 'is-current' : ''); ?>" href="<?php echo e($orderPage->url($number)); ?>" <?php if($current === $number): ?> aria-current="page" <?php endif; ?>><?php echo e($number); ?></a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if($orderPage->hasMorePages()): ?>
            <a class="supplier-orders-page-button" href="<?php echo e($orderPage->nextPageUrl()); ?>" aria-label="Next page">→</a>
        <?php else: ?>
            <span class="supplier-orders-page-button is-disabled" aria-disabled="true" aria-label="Next page">→</span>
        <?php endif; ?>
    </nav>
</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/Supplier_module/resources/views/portal/partials/orders/pagination.blade.php ENDPATH**/ ?>