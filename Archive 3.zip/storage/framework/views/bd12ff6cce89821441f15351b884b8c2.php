<?php
    // The portal is mounted at /supplier/ in production. Submit to that canonical
    // URL so the web server never redirects /supplier?filters to /supplier/.
    $ordersBaseUrl = rtrim(route('supplier.home'), '/').'/';
?>
<form id="supplierOrderFilters" class="supplier-orders-filter-toolbar" method="GET" action="<?php echo e($ordersBaseUrl); ?>" role="search" aria-label="Filter supplier orders">
    <input type="hidden" name="view" value="orders">
    <?php if($orderFilters['quick'] !== ''): ?><input type="hidden" name="quick" value="<?php echo e($orderFilters['quick']); ?>"><?php endif; ?>
    <label class="supplier-orders-search">
        <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><circle cx="10.8" cy="10.8" r="6.8"/><path d="m16 16 4 4"/></svg>
        <input type="search" name="search" value="<?php echo e($orderFilters['search']); ?>" placeholder="Search order, reference or product" autocomplete="off" aria-label="Search order, reference or product">
    </label>
    <div class="supplier-orders-filter-controls">
        <a href="<?php echo e($ordersBaseUrl); ?>?view=orders" class="supplier-orders-filter-chip <?php echo e(!$hasOrderFilters ? 'is-active' : ''); ?>" aria-current="<?php echo e(!$hasOrderFilters ? 'true' : 'false'); ?>">All</a>
        <label class="supplier-orders-filter-chip supplier-orders-hold <?php echo e($orderFilters['hold'] ? 'is-active' : ''); ?>">
            <input type="checkbox" name="hold" value="1" <?php if($orderFilters['hold']): echo 'checked'; endif; ?>>
            <span>Hold on</span>
        </label>
        <select name="stage" aria-label="Workflow stage" class="supplier-orders-filter-select supplier-orders-stage">
            <option value="">All stages</option>
            <?php $__currentLoopData = $orderStages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($id); ?>" <?php if($orderFilters['stage'] === $id): echo 'selected'; endif; ?>><?php echo e($name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <label class="supplier-orders-date"><span>From</span><input type="date" name="from" value="<?php echo e($orderFilters['from']); ?>" aria-label="Created date from"></label>
        <label class="supplier-orders-date"><span>To</span><input type="date" name="to" value="<?php echo e($orderFilters['to']); ?>" min="<?php echo e($orderFilters['from']); ?>" aria-label="Created date to"></label>
        <?php if($hasOrderFilters): ?>
            <a class="supplier-orders-clear" href="<?php echo e($ordersBaseUrl); ?>?view=orders"><span aria-hidden="true">×</span> Clear</a>
        <?php else: ?>
            <span class="supplier-orders-clear is-disabled" aria-disabled="true"><span aria-hidden="true">×</span> Clear</span>
        <?php endif; ?>
    </div>
    <button class="supplier-orders-noscript-submit" type="submit">Apply filters</button>
</form>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/Supplier_module/resources/views/portal/partials/orders/filters.blade.php ENDPATH**/ ?>