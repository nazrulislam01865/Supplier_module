<?php
  $matrixRows = collect($rows ?? [])->values();
  $chargeMap = collect($charges ?? [])->keyBy('quantity');
  $isSupplierMatrix = ($section ?? '') === 'supplier_pricing';
  $matrixColumns = max(1, $matrixRows->count());
  $fieldPrefix = $fieldPrefix ?? 'tiers';
?>
<div class="ft-native-matrix-wrap ft-product-price-preview-wrap ft-product-matrix-scroll" data-native-matrix>
    <div class="ft-native-matrix-scroll" role="region" aria-label="<?php echo e($title ?? 'Pricing'); ?>" tabindex="0">
        <table class="ft-native-price-table ft-product-price-preview ft-product-price-matrix">
            <thead><tr><th scope="col" class="ft-native-rowhead">Quantity</th>
                <?php for($i=0; $i < $matrixColumns; $i++): ?>
                    <th class="ft-native-tier-cell"><?php if($editable ?? false): ?><input type="number" min="1" max="100000000" step="1" name="<?php echo e($fieldPrefix); ?>[<?php echo e($i); ?>][quantity]" value="<?php echo e(old($fieldPrefix.'.'.$i.'.quantity', $matrixRows[$i]['quantity'] ?? '')); ?>" placeholder="Quantity" aria-label="Quantity <?php echo e($i+1); ?>"><?php else: ?><?php echo e(isset($matrixRows[$i]['quantity']) ? number_format((int) $matrixRows[$i]['quantity']) : ''); ?><?php endif; ?></th>
                <?php endfor; ?>
            </tr></thead>
            <tbody>
                <?php $__currentLoopData = array_merge(['price'], $isSupplierMatrix ? ['remote_surcharge', 'standard_shipment', 'urgent_shipment'] : []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr><th scope="row" class="ft-native-rowhead"><?php echo e(match($field) { 'price' => $isSupplierMatrix ? 'Supplier price' : ($fieldPrefix === 'remote_surcharge' ? 'Remote surcharge per unit' : 'Client price'), 'remote_surcharge' => 'Remote surcharge', 'standard_shipment' => 'Standard shipment', default => 'Urgent shipment' }); ?></th>
                        <?php for($i=0; $i < $matrixColumns; $i++): ?>
                            <?php $quantity = $matrixRows[$i]['quantity'] ?? 0; $value = $field === 'price' ? ($matrixRows[$i]['price'] ?? null) : data_get($chargeMap->get($quantity), $field); ?>
                            <td class="ft-native-tier-cell"><?php if($editable ?? false): ?><input type="number" step="0.000001" min="0" name="<?php echo e($fieldPrefix); ?>[<?php echo e($i); ?>][<?php echo e($field); ?>]" value="<?php echo e(old($fieldPrefix.'.'.$i.'.'.$field, $value)); ?>" placeholder="—" aria-label="<?php echo e($field); ?> <?php echo e($i+1); ?>"><?php else: ?><?php echo e($value !== null && $value !== '' ? number_format((float) $value, 2, '.', '') : ''); ?><?php endif; ?></td>
                        <?php endfor; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php if($editable ?? false): ?><div class="ft-native-matrix-controls ft-product-matrix-toolbar"><button type="button" class="ft-native-add-tier">+ Add quantity</button><button type="button" class="ft-native-remove-tier">Remove last quantity</button><small>Quantity-based unit prices. Empty cells are not saved.</small></div><?php endif; ?>
</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel/Supplier_module/resources/views/portal/product-native/matrix.blade.php ENDPATH**/ ?>