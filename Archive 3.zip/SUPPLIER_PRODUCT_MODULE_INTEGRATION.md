# FlowTracker Product module in Supplier Portal — integration and deployment

## What this release implements

- The original FlowTracker **Products / Create Product / Product Detail / Product Categories / Create Product Category** Livewire source is used without replacing it with a different UI. Supplier Portal adds navigation entries that obtain a **signed, single-use access ticket** from FlowTracker and open the original module on a dedicated FlowTracker origin.
- FlowTracker's database is the only authoritative source for Product and Category CRUD, quantity-based supplier/customer prices, product options, availability, shipment charges, product images and supporting documents. Supplier Portal still uses its own login database and does not receive credentials for FlowTracker's database.
- FlowTracker's existing Supplier edit screen receives an **Enable Product module** switch and a matrix of section-wise view/create/edit/delete/manage permissions; matrix is **disabled by default** and verified server-side during operations.
- Products are restricted to the supplier's assigned product links, including supported legacy metadata; supplier cannot change linked supplier assignments and may edit only their own supplier-specific pricing table. Permissions for other confidential sections are separately enforced on the original editor, detail view and product list.
- Ordinary FlowTracker users retain their original Product module. Existing Supplier Portal `Products & Prices` and price-proposal approval endpoints are retained separately.

## Architectural constraint

This is a **delegated launch of the original FlowTracker-hosted UI**, not a second, independently copied Livewire runtime running inside the Supplier Portal codebase. The Supplier Portal Product links navigate to the designated secure FlowTracker Product hostname. This is intentional: an identical standalone runtime would require migrating FlowTracker's master data implementation, dependency graph and storage layer, which is incompatible with the current separate signed-API Supplier Portal architecture. The UI HTML and underlying operations are the original FlowTracker component; it is not a mock or alternate template.

## Permissions configured in FlowTracker

| Section | Actions |
|---|---|
| Products | view, create, edit, delete, manage |
| Categories | view, create, edit, delete, manage |
| Supplier pricing | view, edit |
| Client pricing | view, edit |
| Product options | view, edit |
| Supporting documents and product image | view, edit |
| Shipment and remote surcharge | view, edit |
| Client availability | view, edit |

Every editing permission requires that section's **view** permission. To edit product prices within the editor, grant **Products → View + Edit**, plus the relevant **Supplier pricing / Client pricing → View + Edit**. To use category pages, grant Categories → View plus the intended actions. `Manage` grants all actions within that section only; it never implies another section's permission.

The Product module switch and matrix are in **FlowTracker → Master Data → Suppliers → Edit supplier**. Click **Save Product module permissions**, separate from the normal supplier Save changes action.

## Environment configuration

Apply the **FlowTracker ZIP to the FlowTracker application**, and the **Supplier Portal ZIP to the Supplier Portal application**. Do not overlay one on the other.

Generate one random shared secret (at least 32 characters), configure the existing signed bridge on both sides, and keep the secret out of source control.

### FlowTracker `.env`

```dotenv
FLOWTRACK_SUPPLIER_BRIDGE_ENABLED=true
FLOWTRACK_SUPPLIER_BRIDGE_SECRET=<SAME_STRONG_SECRET_ON_BOTH_APPS>
FLOWTRACK_SUPPLIER_PRODUCT_MODULE_URL=https://supplier-products.example.com
```

The `supplier-products.example.com` hostname is an example: configure it as a **dedicated HTTPS virtual host serving the SAME FlowTracker Laravel application and database** as normal `flowtracker.example.com`, not the Supplier Portal application. Point it at the FlowTracker `public/` directory and use your actual SSL certificate and forwarded proxy headers.

### Supplier Portal `.env`

```dotenv
FLOWTRACK_BRIDGE_ENABLED=true
FLOWTRACK_SUPPLIER_BRIDGE_SECRET=<SAME_STRONG_SECRET_ON_BOTH_APPS>
FLOWTRACK_BUYER_URL=https://flowtracker.example.com
FLOWTRACK_SUPPLIER_PRODUCT_MODULE_URL=https://supplier-products.example.com
```

Use your real FlowTracker API origin for `FLOWTRACK_BUYER_URL` and the exact dedicated Product origin (scheme, host and optional port) for `FLOWTRACK_SUPPLIER_PRODUCT_MODULE_URL`. A separate host avoids overwriting the normal FlowTracker administrator's browser session when switching to a supplier user. Configure **host-only cookies** (`SESSION_DOMAIN=null` or omit shared-domain cookie configuration); do not set a cookie domain common to admin and supplier Product hosts. Configure your proxies and Laravel trust-proxy settings so `Request::getSchemeAndHttpHost()` sees the actual HTTPS origin. API calls use your existing bridge secret and HMAC signature; no new direct portal database connection is required.

## Deployment order

Back up the FlowTracker database and both application versions. Deploy the FlowTracker project first.

```bash
# In FlowTracker root
php artisan migrate --force
php artisan optimize:clear
php artisan route:list --path=api/supplier-bridge/product-module
php artisan route:list --path=supplier-product/access
```

Deploy the Supplier Portal project afterward:

```bash
# In Supplier Portal root
php artisan optimize:clear
php artisan route:list --path=products/module
```

If your deployment build includes changes to compiled front-end assets, run your existing npm/Vite build procedure. This update adds no new JavaScript package or alternate product UI. Restart queue workers only if your deployment policy requires it; existing jobs/bridges remain intact.

## Activate and verify

1. In FlowTracker, open an active supplier in the Supplier edit screen. Check **Enable Product module** and grant **Products → View** (and any other intended permissions). Save the Product module matrix.
2. Verify Supplier Portal's company has its correct `flowtrack_supplier_id` mapped to that FlowTracker supplier and that the supplier account is active.
3. In the Supplier Portal sidebar, click **Products** or **Product Categories**. Portal sends an HMAC-signed request, FlowTracker issues a 45-second single-use ticket, the dedicated host consumes it and opens the original Product module with a restricted 20-minute session.
4. Test no-access, view-only, create, edit, delete, own supplier price table, client price table, category actions, document upload/download, shipment, and client availability independently. Check an unassigned product URL and a forbidden FlowTracker dashboard URL both return access denied.
5. Disable Product module access in FlowTracker and confirm the currently open supplier screen can no longer perform operations. Sign out of Supplier Portal and confirm revocation of delegated Product sessions.
6. Run Laravel automated tests against your actual MySQL database and installed Composer packages before deploying publicly; this archive does **not** contain `vendor/` or a seeded integration database.

## Security and compatibility notes

- Supplier access is **deny by default**. It is checked by FlowTracker on every request, including Livewire saves, not just by hiding controls.
- Signed bridge requests include an event UUID, timestamp and HMAC. Ticket consumption is one-use, with database row locks and a short lifetime.
- Product scoping excludes other suppliers' products from ordinary queries. Supplier price editing is restricted to their own linked row; the shared fallback table and other suppliers' price rows are preserved.
- Existing staff exports are unchanged. Supplier-side Excel export is intentionally disabled: the original export contains fields spanning several separately controlled permissions and would otherwise expose hidden columns.
- The existing Supplier Portal price-proposal/approval workflow is **not replaced**; grants in the new Product module authorize direct edits through the original FlowTracker editor. Decide explicitly which suppliers should receive those grants.
- Do **not** expose the delegated launch URL through untrusted `return_to` query parameters or share tickets between users. Use HTTPS, separate hosts and short-lived cookies.

## Verification performed on the supplied archives

- PHP lint passed over all **787 FlowTracker PHP files** and **81 Supplier Portal PHP files** present in the relevant application directories.
- Five isolated permission-matrix regression checks passed.
- Project diff checks confirmed the original archives had no deleted/missing files; source changes are limited to the listed integration, permission and Product-screen files.
- **Not verified:** end-to-end HTTP login/Livewire interactions, MySQL migration execution, or integration with a real supplier account; composer `vendor/`, running application servers and database credentials were not supplied. The new module therefore requires staging testing before production use. Do not treat source-level checks as proof of a working production deployment.
